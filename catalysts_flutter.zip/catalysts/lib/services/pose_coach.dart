import 'dart:math';

import '../state.dart';

/// One frame of pose data for the trained behaviour.
class PoseFrame {
  final double raise; // 0..1, how far the paw (or pose) is towards the target
  final double holding; // seconds the pose has been held
  final bool crossedTarget; // true on the frame the hold reaches the target
  final RepResult? finished; // non-null on the frame a rep ends
  const PoseFrame(this.raise, this.holding, {this.crossedTarget = false, this.finished});
}

class _ActiveRep {
  final Duration t0;
  final double hold, height;
  bool clicked = false;
  _ActiveRep(this.t0, this.hold, this.height);
}

/// Produces pose frames for a training session.
///
/// This is SIMULATED. In production, replace [tick] with the output of a cat
/// pose model running on the camera stream (phone camera via the `camera`
/// package, or the pet camera's RTSP/WebRTC feed): take the front-paw
/// keypoint's height relative to the shoulder as `raise`, and measure how long
/// it stays above the threshold as `holding`. Everything downstream (scoring,
/// feedback, XP, summaries) works unchanged.
class PoseCoach {
  final double target;
  PoseCoach({this.target = 2.0});

  final _r = Random();
  _ActiveRep? _rep;
  final List<RepResult> reps = [];
  bool auto = true;
  Duration _lastCue = Duration.zero;

  bool get busy => _rep != null;

  void cue(Duration now) {
    if (_rep != null) return;
    final n = reps.length;
    // Holds get longer and reach gets higher as the trainer follows feedback.
    final hold = min(3.0, 0.7 + _r.nextDouble() * 1.3 + n * 0.28);
    final height = min(1.0, 0.5 + _r.nextDouble() * 0.35 + n * 0.06);
    _rep = _ActiveRep(now, hold, height);
  }

  PoseFrame tick(Duration now) {
    if (_rep == null && auto && now - _lastCue > const Duration(milliseconds: 1600)) cue(now);
    final r = _rep;
    if (r == null) return const PoseFrame(0, 0);
    final t = (now - r.t0).inMicroseconds / 1e6;
    const up = 0.45, down = 0.4;
    double raise, holding = 0;
    var crossed = false;
    RepResult? done;
    if (t < up) {
      raise = t / up;
    } else if (t < up + r.hold) {
      raise = 1;
      holding = t - up;
      if (holding >= target && !r.clicked) {
        r.clicked = true;
        crossed = true;
      }
    } else if (t < up + r.hold + down) {
      raise = 1 - (t - up - r.hold) / down;
      holding = r.hold;
    } else {
      raise = 0;
      holding = r.hold;
      final score = ((min(1.0, r.hold / target) * 0.7 + r.height * 0.3) * 100).round();
      done = RepResult(r.hold, r.height, score);
      reps.add(done);
      _rep = null;
      _lastCue = now;
      if (reps.length >= 8) auto = false;
    }
    return PoseFrame(raise * r.height, holding, crossedTarget: crossed, finished: done);
  }

  int get accuracy => reps.isEmpty ? 0 : (reps.map((r) => r.score).reduce((a, b) => a + b) / reps.length).round();
}

/// Rule-based coaching feedback for one rep: (good, title, body).
(bool, String, String) feedbackFor(RepResult r, int repNo, String cat, String trick, double target) {
  final paw = trick == 'High Five';
  final pct = (r.height * 100).round();
  if (r.hold < 1.3) {
    return (
      false,
      'Rep $repNo: ${paw ? 'Paw' : 'Pose'} dropped after ${r.hold.toStringAsFixed(1)} s',
      '$cat is releasing too early. Delay your click by half a second each rep, and only treat holds longer than ${min(target, r.hold + 0.4).toStringAsFixed(1)} s.'
    );
  }
  if (r.height < 0.72) {
    return (
      false,
      'Rep $repNo: ${paw ? 'Paw stayed low' : 'Pose only partly matched'} ($pct%)',
      paw
          ? 'Hold your palm about 5 cm higher so $cat has to reach, and keep the treat hand above $cat\'s head.'
          : 'Guide $cat slowly with the treat so the full movement happens before you click.'
    );
  }
  if (r.hold < target) {
    return (
      false,
      'Rep $repNo: Almost, ${r.hold.toStringAsFixed(1)} s hold',
      'Good height. Stay still with your palm for a moment longer; moving your hand ends the hold.'
    );
  }
  return (
    true,
    'Rep $repNo: Clean rep · ${r.hold.toStringAsFixed(1)} s at $pct%',
    'That\'s the one. The click marked it at ${target.toStringAsFixed(1)} s. Treat right away.'
  );
}
