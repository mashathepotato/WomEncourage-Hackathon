import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Real OS notifications, so the nudge appears while the user is in another
/// app (Instagram, etc.), Duolingo-style. Tapping it calls [onTap].
class Reminders {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static VoidCallback? onTap;
  static bool _ready = false;

  static const _details = NotificationDetails(
    android: AndroidNotificationDetails(
      'training',
      'Training reminders',
      channelDescription: 'Daily nudges to train your cat',
      importance: Importance.high,
      priority: Priority.high,
    ),
    iOS: DarwinNotificationDetails(),
  );

  static bool get supported =>
      !kIsWeb && (defaultTargetPlatform == TargetPlatform.android || defaultTargetPlatform == TargetPlatform.iOS);

  static Future<void> init() async {
    if (!supported) return;
    try {
      await _plugin.initialize(
        const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
          iOS: DarwinInitializationSettings(
            requestAlertPermission: false,
            requestBadgePermission: false,
            requestSoundPermission: false,
          ),
        ),
        onDidReceiveNotificationResponse: (_) => onTap?.call(),
      );
      _ready = true;
    } catch (e) {
      debugPrint('Notifications unavailable: $e');
    }
  }

  static Future<void> requestPermission() async {
    if (!_ready) return;
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
    await _plugin
        .resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(alert: true, badge: true, sound: true);
  }

  /// Fire one immediately (used by "Send a real test notification").
  static Future<bool> showNow(String title, String body) async {
    if (!_ready) return false;
    await requestPermission();
    await _plugin.show(1, title, body, _details);
    return true;
  }

  /// Repeat daily from now. For a fixed time of day (e.g. 18:30) switch to
  /// `zonedSchedule` with the `timezone` package.
  static Future<void> enableDaily(String title, String body) async {
    if (!_ready) return;
    await requestPermission();
    await _plugin.periodicallyShow(2, title, body, RepeatInterval.daily, _details,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle);
  }

  static Future<void> disableDaily() async {
    if (!_ready) return;
    await _plugin.cancel(2);
  }
}
