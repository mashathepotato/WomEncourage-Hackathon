import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../services/pose_coach.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/painters.dart';
import 'sheets.dart';

/// Opens the next part of the current lesson:
/// quiz → pre-check → camera training → summary → check-in → result → activity.
Future<void> openLessonFlow(BuildContext context) async {
  final s = context.sr;
  if (s.lesson.done == 3) {
    s.startNextLesson();
    toast(context, 'Lesson ${s.lesson.n}: ${s.lesson.trick}');
    return;
  }
  final start = !s.lesson.quiz
      ? LStep.quiz
      : !s.lesson.training
          ? LStep.pre
          : LStep.activity;
  await showSheet(context, (_) => LessonFlow(start: start), enableDrag: false);
}

enum LStep { quiz, pre, training, summary, checkin, result, activity }

class LessonFlow extends StatefulWidget {
  final LStep start;
  const LessonFlow({super.key, required this.start});
  @override
  State<LessonFlow> createState() => _LessonFlowState();
}

class _LessonFlowState extends State<LessonFlow> {
  late LStep step = widget.start;
  String? answer;
  int pre = 50, post = 40;
  int? mood;
  final helped = <String>{};
  SessionSummary? summary;
  final checks = [false, false, false];

  @override
  void initState() {
    super.initState();
    final s = context.sr;
    pre = s.latest['stress'];
  }

  void go(LStep n) => setState(() => step = n);

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 220),
      child: KeyedSubtree(
        key: ValueKey(step),
        child: switch (step) {
          LStep.quiz => _quiz(s),
          LStep.pre => _pre(s),
          LStep.training => TrainingView(onFinish: (reps, elapsed) {
              summary = s.completeTraining(reps, elapsed);
              post = max(5, pre - 10);
              go(LStep.summary);
            }),
          LStep.summary => _summary(s),
          LStep.checkin => _checkin(s),
          LStep.result => _result(s),
          LStep.activity => _activity(s),
        },
      ),
    );
  }

  /* ---------- quiz ---------- */
  Widget _quiz(AppState s) {
    final c = context.c;
    final opts = [
      ('a', 'After ${s.cat} eats the treat'),
      ('b', 'The moment the paw touches your hand'),
      ('c', 'Before you raise your hand'),
    ];
    final ok = answer == 'b';
    return SheetBody(children: [
      Muted('Lesson ${s.lesson.n} · Quiz'),
      const SheetTitle('When should you click?'),
      for (final o in opts)
        Material(
          color: c.card,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(
                width: 2,
                color: answer == o.$1 ? (o.$1 == 'b' ? c.ok : c.bad) : Colors.transparent),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => setState(() => answer = o.$1),
            child: Padding(padding: const EdgeInsets.all(14), child: Text(o.$2)),
          ),
        ),
      if (answer != null)
        Muted(ok
            ? 'Right. The click marks the exact behaviour you want.'
            : 'Not quite. The click has to land on the behaviour itself.'),
      ButtonRow([
        Pill('Next: Training', onPressed: ok
            ? () {
                s.completeQuiz();
                go(LStep.pre);
              }
            : null),
      ]),
    ]);
  }

  /* ---------- pre-session check ---------- */
  Widget _pre(AppState s) => SheetBody(children: [
        const Muted('Before you start'),
        const SheetTitle('How stressed do you feel right now?'),
        LabeledSlider(label: 'Stress', value: pre, onChanged: (v) => setState(() => pre = v)),
        const Muted('We compare this with how you feel after the session.', size: 12),
        ButtonRow([
          Pill('Open ${s.camLabel}',
              icon: s.usingPetcam ? Icons.videocam_outlined : Icons.photo_camera_outlined,
              onPressed: () => go(LStep.training)),
        ]),
      ]);

  /* ---------- summary ---------- */
  Widget _summary(AppState s) {
    final c = context.c, m = summary!;
    final rankText = m.rankAfter < m.rankBefore
        ? 'Up to ${m.rankAfter}${ordinal(m.rankAfter)} in ${tierNames[s.league]} League'
        : '${m.rankAfter}${ordinal(m.rankAfter)} in ${tierNames[s.league]} League';
    final good = m.clean >= m.reps / 2;
    return SheetBody(children: [
      const Hero92(Icons.emoji_events),
      const SheetTitle('Session complete. Nice work, you two!', center: true),
      CardBox(
        child: Column(children: [
          const Muted('This week you spent'),
          Text('${m.thisWeek} min', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w700, color: c.accent)),
          Text.rich(
            TextSpan(children: [
              TextSpan(text: 'with ${s.cat}, '),
              TextSpan(
                text: m.weekChangePct >= 0 ? '${m.weekChangePct}% more' : '${-m.weekChangePct}% less',
                style: TextStyle(color: c.ok, fontWeight: FontWeight.w600),
              ),
              const TextSpan(text: ' than last week'),
            ]),
            textAlign: TextAlign.center,
          ),
        ]),
      ),
      CardBox(
        child: StatTriple([
          ('${m.accuracy}%', 'Accuracy'),
          ('${m.bestHold.toStringAsFixed(1)}s', 'Best hold'),
          ('${m.clean}/${m.reps}', 'Clean reps'),
        ]),
      ),
      CardBox(
        child: Row(children: [
          TierShield(size: 36, color: tierColors[s.league]),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('+${m.xp} XP', style: const TextStyle(fontWeight: FontWeight.w600)),
              Muted('$rankText${m.rankAfter <= 3 ? ' · promotion zone' : ''}', size: 12),
            ]),
          ),
        ]),
      ),
      FeedbackTile(
        good: good,
        title: 'Coach\'s note',
        body: good
            ? '${s.cat} is holding longer rep after rep. Next session, raise the target to 2.5 s.'
            : 'Holds are still short. Keep the target at 2.0 s and click a little later next time.',
      ),
      ButtonRow([
        Pill('Share',
            ghost: true,
            icon: Icons.ios_share,
            onPressed: () => showComposeSheet(context,
                caption: '${s.cat} scored ${m.accuracy}% on ${s.lesson.trick} today!',
                achievement: '${s.lesson.trick} · ${m.accuracy}% accuracy')),
        Pill('Next: quick check-in', onPressed: () => go(LStep.checkin)),
      ]),
    ]);
  }

  /* ---------- check-in ---------- */
  Widget _checkin(AppState s) {
    final c = context.c;
    const faces = [
      (Icons.sentiment_very_dissatisfied, 'Much worse'),
      (Icons.sentiment_dissatisfied, 'Worse'),
      (Icons.sentiment_neutral, 'Same'),
      (Icons.sentiment_satisfied, 'Better'),
      (Icons.sentiment_very_satisfied, 'Much better'),
    ];
    return SheetBody(children: [
      const Muted('Check-in · 20 seconds'),
      SheetTitle('How do you feel after training with ${s.cat}?'),
      Row(
        children: hspaced([
          for (var i = 0; i < faces.length; i++)
            Expanded(
              child: Material(
                color: c.card,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: mood == i ? c.accent : Colors.transparent, width: 2),
                ),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => setState(() => mood = i),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Column(children: [
                      Icon(faces[i].$1, size: 28, color: mood == i ? c.accent : c.muted),
                      const SizedBox(height: 4),
                      Text(faces[i].$2,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 10,
                              color: mood == i ? c.accent : c.muted,
                              fontWeight: mood == i ? FontWeight.w600 : null)),
                    ]),
                  ),
                ),
              ),
            ),
        ], 6),
      ),
      LabeledSlider(label: 'Stress right now', value: post, onChanged: (v) => setState(() => post = v)),
      const Text('Did it help with any of these?', style: TextStyle(fontSize: 14)),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final g in goals)
          ToggleChip(
            label: g.$3,
            selected: helped.contains(g.$1),
            onTap: () => setState(() => helped.contains(g.$1) ? helped.remove(g.$1) : helped.add(g.$1)),
          ),
      ]),
      ButtonRow([
        Pill('See my results', onPressed: mood == null
            ? null
            : () {
                s.recordCheckIn(pre, post, mood);
                go(LStep.result);
              }),
      ]),
    ]);
  }

  /* ---------- result ---------- */
  Widget _result(AppState s) {
    final c = context.c;
    final drop = pre == 0 ? 0 : ((pre - post) / pre * 100).round();
    final total = s.stressDropSinceStart;
    return SheetBody(children: [
      const Muted('Your results'),
      CardBox(
        child: Column(children: [
          const Muted('Stress after this session'),
          Text('${drop >= 0 ? '−' : '+'}${drop.abs()}%',
              style: TextStyle(fontSize: 44, fontWeight: FontWeight.w700, color: c.accent)),
          Muted('$pre% before · $post% after', size: 12),
        ]),
      ),
      CardBox(
        child: Row(children: [
          const Expanded(child: Text('Since your first survey')),
          Text('${total > 0 ? '−' : '+'}${total.abs()}% stress',
              style: TextStyle(fontWeight: FontWeight.w600, color: total > 0 ? c.ok : c.ink)),
        ]),
      ),
      const FeedbackTile(
        good: true,
        title: 'What this means',
        body: 'Short, hands-on time with a pet is linked to lower stress hormones in research studies. '
            'Your own check-ins show the same pattern.',
      ),
      Pill('Learn more about the research', ghost: true, onPressed: () => showLearnSheet(context)),
      ButtonRow([Pill('Continue to activity', onPressed: () => go(LStep.activity))]),
    ]);
  }

  /* ---------- activity ---------- */
  Widget _activity(AppState s) {
    final c = context.c;
    const tasks = ['Ask for a high five before dinner', 'Try it in a different room', 'Get a family member to ask'];
    return SheetBody(children: [
      Muted('Lesson ${s.lesson.n} · Activity'),
      const SheetTitle('Practise through the day'),
      for (var i = 0; i < tasks.length; i++)
        Material(
          color: c.card,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => setState(() => checks[i] = !checks[i]),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                Icon(checks[i] ? Icons.check_box : Icons.check_box_outline_blank, color: c.accent),
                const SizedBox(width: 10),
                Expanded(child: Text(tasks[i])),
              ]),
            ),
          ),
        ),
      ButtonRow([
        Pill('Complete lesson', onPressed: checks.every((x) => x)
            ? () {
                s.completeActivity();
                toast(context, 'Lesson ${s.lesson.n} complete');
                Navigator.pop(context);
                s.update(() => s.tab = AppTab.home);
              }
            : null),
      ]),
    ]);
  }
}

/* ======================= camera-coached training ======================= */

class TrainingView extends StatefulWidget {
  final void Function(List<RepResult> reps, Duration elapsed) onFinish;
  const TrainingView({super.key, required this.onFinish});
  @override
  State<TrainingView> createState() => _TrainingViewState();
}

class _TrainingViewState extends State<TrainingView> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  final coach = PoseCoach();
  Duration now = Duration.zero;
  PoseFrame frame = const PoseFrame(0, 0);
  final feedback = <(bool, String, String)>[];

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_onTick)..start();
  }

  void _onTick(Duration elapsed) {
    final s = context.sr;
    final f = coach.tick(elapsed);
    if (f.crossedTarget) playClick(s);
    if (f.finished != null) {
      feedback.insert(0, feedbackFor(f.finished!, coach.reps.length, s.cat, s.lesson.trick, coach.target));
      if (feedback.length > 3) feedback.removeLast();
    }
    setState(() {
      now = elapsed;
      frame = f;
    });
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s, c = context.c;
    final paw = s.lesson.trick == 'High Five';
    final hold = min(frame.holding, 3.0);
    final last = coach.reps.isEmpty ? null : coach.reps.last;
    final secs = now.inSeconds;
    Widget meter(String label, String value) => Expanded(
          child: CardBox(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label.toUpperCase(),
                  style: TextStyle(fontSize: 10, letterSpacing: .6, fontWeight: FontWeight.w600, color: c.muted)),
              Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            ]),
          ),
        );
    return SheetBody(children: [
      Row(children: [
        Expanded(child: Muted('Lesson ${s.lesson.n} · Training')),
        Muted('${secs ~/ 60}:${(secs % 60).toString().padLeft(2, '0')}', size: 12),
      ]),
      SheetTitle('${s.lesson.trick} · hold ${paw ? 'the paw' : 'the pose'} for ${coach.target.toStringAsFixed(1)} s'),
      ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: AspectRatio(
          aspectRatio: 640 / 420,
          child: Stack(fit: StackFit.expand, children: [
            CustomPaint(
              painter: CameraPainter(
                raise: frame.raise,
                holding: frame.holding,
                target: coach.target,
                t: now.inMicroseconds / 1e6,
                catName: s.cat,
              ),
            ),
            Positioned(
              top: 8,
              left: 8,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(6)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Container(
                      width: 7, height: 7, decoration: const BoxDecoration(color: Color(0xFFFF4D5E), shape: BoxShape.circle)),
                  const SizedBox(width: 6),
                  Text('LIVE · ${s.camLabel}', style: const TextStyle(color: Colors.white, fontSize: 11)),
                ]),
              ),
            ),
          ]),
        ),
      ),
      Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          const Expanded(child: Text('Hold time', style: TextStyle(fontSize: 13))),
          Text('${hold.toStringAsFixed(1)} s / ${coach.target.toStringAsFixed(1)} s', style: const TextStyle(fontSize: 13)),
        ]),
        const SizedBox(height: 6),
        HoldBar(value: hold / 3, marker: coach.target / 3, color: hold >= coach.target ? c.ok : c.accent),
      ]),
      Row(
          children: hspaced([
        meter('Reps', '${coach.reps.length}'),
        meter(paw ? 'Paw height' : 'Pose match', last == null ? '–' : '${(last.height * 100).round()}%'),
        meter('Accuracy', coach.reps.isEmpty ? '–' : '${coach.accuracy}%'),
      ], 8)),
      if (feedback.isEmpty)
        FeedbackTile(
            title: 'Watching ${s.cat}',
            body: 'Raise your palm and say the cue. The camera scores each rep and suggests fixes.')
      else
        for (final f in feedback) FeedbackTile(good: f.$1, title: f.$2, body: f.$3),
      ButtonRow([
        Pill('Cue now', ghost: true, onPressed: coach.busy ? null : () {
          coach.auto = false;
          coach.cue(now);
        }),
        Pill(coach.reps.length >= 3 ? 'Finish session' : 'Finish session (3 reps min)',
            onPressed: coach.reps.length >= 3
                ? () {
                    _ticker.stop();
                    widget.onFinish(List.of(coach.reps), now);
                  }
                : null),
      ]),
    ]);
  }
}
