import 'package:flutter/material.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'lesson_flow.dart';
import 'sheets.dart';

void openOnboarding(BuildContext context) {
  final nav = Navigator.of(context);
  nav.push(MaterialPageRoute(
    fullscreenDialog: true,
    builder: (_) => OnboardingPage(onFinish: (startLesson) {
      nav.pop();
      if (startLesson) openLessonFlow(nav.context);
    }),
  ));
}

class OnboardingPage extends StatefulWidget {
  final void Function(bool startLesson) onFinish;
  const OnboardingPage({super.key, required this.onFinish});
  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  int step = 0;
  static const steps = 5;

  void _next() => setState(() => step++);

  @override
  Widget build(BuildContext context) {
    final s = context.s, c = context.c;
    final content = switch (step) {
      0 => _welcome(s, c),
      1 => _feelings(s, c),
      2 => _goals(s, c),
      3 => _camera(s, c),
      _ => _done(s, c),
    };
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: c.screen,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(children: [
                for (var i = 0; i < steps; i++)
                  Expanded(
                    child: Container(
                      height: 5,
                      margin: EdgeInsets.only(right: i == steps - 1 ? 0 : 6),
                      decoration: BoxDecoration(
                          color: i <= step ? c.accent : c.line, borderRadius: BorderRadius.circular(3)),
                    ),
                  ),
              ]),
              const SizedBox(height: 24),
              Expanded(child: content),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _scroll(List<Widget> top, List<Widget> bottom) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(
          child: SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: vspaced(top, 14)),
          ),
        ),
        const SizedBox(height: 12),
        ...vspaced(bottom, 10),
      ]);

  Widget _welcome(AppState s, AppColors c) => _scroll([
        const SizedBox(height: 24),
        const Hero92(Icons.pets, size: 110),
        Text.rich(
          TextSpan(children: [
            TextSpan(text: 'Welcome to ', style: TextStyle(color: c.ink)),
            TextSpan(text: 'CAT', style: TextStyle(color: c.accent)),
            TextSpan(text: 'alysts', style: TextStyle(color: c.ink)),
          ]),
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700),
        ),
        const Text(
          'Five-minute training sessions with your cat, coached by your camera. '
          'We also track how the time together affects your stress and mood.',
          textAlign: TextAlign.center,
          style: TextStyle(height: 1.6),
        ),
      ], [
        Pill('Get started', onPressed: _next),
        Pill('Skip for now', ghost: true, onPressed: () {
          s.finishOnboarding();
          widget.onFinish(false);
        }),
      ]);

  Widget _feelings(AppState s, AppColors c) => _scroll([
        const Muted('Step 1 of 3 · about you'),
        const SheetTitle('How have you felt over the past two weeks?'),
        const Muted('0% is none at all, 100% is the most you can imagine.'),
        for (final m in metrics)
          LabeledSlider(label: m.$2, value: s.baseline[m.$1], onChanged: (v) => s.update(() => s.baseline[m.$1] = v)),
      ], [
        ButtonRow([Pill('Next', onPressed: _next)]),
      ]);

  Widget _goals(AppState s, AppColors c) => _scroll([
        const Muted('Step 2 of 3 · your goals'),
        const SheetTitle('What would you like to improve?'),
        const Muted('Pick any. We use this to recommend lessons and measure what changes.'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final g in goals)
            ToggleChip(
              label: g.$2,
              selected: s.goalSet.contains(g.$1),
              onTap: () => s.update(() => s.goalSet.contains(g.$1) ? s.goalSet.remove(g.$1) : s.goalSet.add(g.$1)),
            ),
        ]),
      ], [
        ButtonRow([Pill('Next', onPressed: _next)]),
      ]);

  Widget _camera(AppState s, AppColors c) => _scroll([
        const Muted('Step 3 of 3 · coaching camera'),
        SheetTitle('Which camera should watch ${s.cat} train?'),
        Muted('The camera tracks ${s.cat}\'s movement during a session and scores each rep. It only runs while a session is open.'),
        ...cameraOptions(context, s),
      ], [
        ButtonRow([Pill('Next', onPressed: _next)]),
      ]);

  Widget _done(AppState s, AppColors c) {
    final picked = goals.where((g) => s.goalSet.contains(g.$1)).toList();
    return _scroll([
      const SizedBox(height: 12),
      const Hero92(Icons.check, size: 110),
      const SheetTitle('You\'re set', center: true),
      const Text(
        'Your starting point is saved. After each session you\'ll answer one quick check-in so we can show what\'s changing.',
        textAlign: TextAlign.center,
        style: TextStyle(height: 1.6),
      ),
      CardBox(
        child: picked.isEmpty
            ? const Muted('No goals picked')
            : Column(children: [
                for (var i = 0; i < picked.length; i++)
                  InfoRow(
                    title: picked[i].$2,
                    last: i == picked.length - 1,
                    trailing: Text('${s.baseline[picked[i].$1]}% now', style: const TextStyle(fontWeight: FontWeight.w600)),
                  ),
              ]),
      ),
    ], [
      Pill('Start Lesson ${s.lesson.n}', onPressed: () {
        s.finishOnboarding();
        widget.onFinish(true);
      }),
    ]);
  }
}
