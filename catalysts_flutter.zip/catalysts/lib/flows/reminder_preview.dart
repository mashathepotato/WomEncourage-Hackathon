import 'package:flutter/material.dart';

import '../services/reminders.dart';
import '../state.dart';
import '../widgets/common.dart';
import 'lesson_flow.dart';

/// Shows how the Duolingo-style nudge looks when the user is in another app.
/// The real version is an OS notification from [Reminders].
void openReminderPreview(BuildContext context) {
  final nav = Navigator.of(context);
  nav.push(PageRouteBuilder(
    opaque: true,
    pageBuilder: (_, __, ___) => ReminderPreviewPage(onOpen: () {
      nav.pop();
      openLessonFlow(nav.context);
    }),
    transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
  ));
}

class ReminderPreviewPage extends StatefulWidget {
  final VoidCallback onOpen;
  const ReminderPreviewPage({super.key, required this.onOpen});
  @override
  State<ReminderPreviewPage> createState() => _ReminderPreviewPageState();
}

class _ReminderPreviewPageState extends State<ReminderPreviewPage> {
  bool _show = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) setState(() => _show = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final body = '${s.cat} is waiting! You haven\'t trained today. 5 minutes keeps your ${s.streak}-day streak alive.';
    return Scaffold(
      backgroundColor: const Color(0xFF101014),
      body: SafeArea(
        child: Stack(children: [
          // stand-in for another app's photo feed
          ListView(padding: const EdgeInsets.fromLTRB(14, 80, 14, 90), children: [
            const Text('Another app · photo feed', style: TextStyle(color: Color(0xFF888888), fontSize: 12)),
            const SizedBox(height: 12),
            for (var i = 0; i < 3; i++)
              Container(
                height: 240,
                margin: const EdgeInsets.only(bottom: 14),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: const Color(0xFF1E1E26), borderRadius: BorderRadius.circular(12)),
                alignment: Alignment.bottomLeft,
                child: const Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _Bar(.6),
                  SizedBox(height: 6),
                  _Bar(.4),
                ]),
              ),
          ]),
          AnimatedPositioned(
            duration: const Duration(milliseconds: 500),
            curve: Curves.easeOutBack,
            left: 10,
            right: 10,
            top: _show ? 10 : -140,
            child: GestureDetector(
              onTap: widget.onOpen,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xF7F5F4FC),
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 30, offset: Offset(0, 10))],
                ),
                child: Row(children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(color: const Color(0xFF7B6DBD), borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.pets, color: Colors.white),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Row(children: [
                        Text('CATalysts',
                            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Color(0xFF26243A))),
                        SizedBox(width: 6),
                        Text('now', style: TextStyle(fontSize: 11, color: Color(0xFF777777))),
                      ]),
                      Text(body, style: const TextStyle(fontSize: 13, color: Color(0xFF26243A))),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 20,
            child: Center(
              child: ButtonRow(alignment: WrapAlignment.center, [
                Pill('Back to CATalysts',
                    small: true,
                    background: const Color(0xFF333333),
                    foreground: const Color(0xFFEEEEEE),
                    onPressed: () => Navigator.pop(context)),
                if (Reminders.supported)
                  Pill('Send as real notification',
                      small: true,
                      onPressed: () => Reminders.showNow('CATalysts', body)),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

class _Bar extends StatelessWidget {
  final double f;
  const _Bar(this.f);
  @override
  Widget build(BuildContext context) => FractionallySizedBox(
        widthFactor: f,
        child: Container(height: 8, decoration: BoxDecoration(color: const Color(0xFF34343F), borderRadius: BorderRadius.circular(4))),
      );
}
