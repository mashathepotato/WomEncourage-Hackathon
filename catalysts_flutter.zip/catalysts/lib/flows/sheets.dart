import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/painters.dart';
import 'reminder_preview.dart';

/* ---------------- library ---------------- */

void showTrickSheet(BuildContext context, String id) {
  final s = context.sr;
  s.openTrick(id);
  final t = tricks[id]!;
  showSheet(context, (ctx) {
    final c = ctx.c;
    return SheetBody(children: [
      Row(children: [
        Badge58(t.icon),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SheetTitle(t.name),
            Text('${t.category} · ${t.mins} min · camera coached', style: TextStyle(color: c.muted, fontSize: 13)),
          ]),
        ),
      ]),
      Text(
          'Break ${t.name.toLowerCase()} into small steps and reward each one with a click and a treat. '
          'The camera times each rep and tells you when to raise the bar.',
          style: const TextStyle(height: 1.6)),
      ButtonRow([
        Pill('Close', ghost: true, onPressed: () => Navigator.pop(ctx)),
        Pill('Mark practised', onPressed: () {
          s.markPractised(id);
          Navigator.pop(ctx);
          toast(context, 'Session logged. Streak updated');
        }),
      ]),
    ]);
  });
}

void showBlogSheet(BuildContext context, String title) {
  showSheet(
      context,
      (ctx) => SheetBody(children: [
            SheetTitle(title),
            const Text('Example article. In the full app this opens the blog post.', style: TextStyle(height: 1.6)),
            ButtonRow([Pill('Close', onPressed: () => Navigator.pop(ctx))]),
          ]));
}

/* ---------------- header ---------------- */

void showCatPicker(BuildContext context) {
  showSheet(context, (ctx) {
    final s = ctx.s;
    return SheetBody(children: [
      const SheetTitle('Choose a cat'),
      for (final name in s.cats)
        SelectTile(
          icon: Icons.pets,
          title: name,
          subtitle: name == s.cat ? 'Selected' : 'Tap to switch',
          selected: name == s.cat,
          onTap: () {
            s.update(() => s.cat = name);
            Navigator.pop(ctx);
          },
        ),
      SelectTile(
        icon: Icons.add,
        title: 'Add a cat',
        subtitle: 'Create a new profile',
        selected: false,
        onTap: () {
          final n = s.addCat();
          Navigator.pop(ctx);
          toast(context, n != null ? '$n added' : 'Demo supports up to 5 cats');
        },
      ),
    ]);
  });
}

Widget _notif(BuildContext ctx, IconData icon, String title, String sub) {
  final c = ctx.c;
  return CardBox(
    padding: const EdgeInsets.all(12),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: c.accent),
      const SizedBox(width: 12),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
          Text(sub, style: TextStyle(color: c.muted, fontSize: 13)),
        ]),
      ),
    ]),
  );
}

void showInfoSheet(BuildContext context) {
  showSheet(context, (ctx) {
    final s = ctx.s;
    return SheetBody(children: [
      const SheetTitle('About CATalysts'),
      _notif(ctx, Icons.photo_camera_outlined, 'Camera coaching',
          'Your phone or pet camera tracks ${s.cat} during a session, times each hold and suggests fixes.'),
      _notif(ctx, Icons.sports, 'Clicker', 'Tap the whistle at the top. Click at the exact moment your cat does the right thing.'),
      _notif(ctx, Icons.favorite_border, 'Wellbeing check-ins',
          'A short check-in before and after each session shows how training affects your stress.'),
      ButtonRow([
        Pill('The research', ghost: true, onPressed: () => showLearnSheet(ctx)),
        Pill('Got it', onPressed: () => Navigator.pop(ctx)),
      ]),
    ]);
  });
}

void showNotificationsSheet(BuildContext context) {
  context.sr.update(() => context.sr.unread = 0);
  showSheet(context, (ctx) {
    final s = ctx.s;
    return SheetBody(children: [
      const SheetTitle('Notifications'),
      _notif(ctx, Icons.notifications_none, 'Time to train ${s.cat}', 'Keep your ${s.streak}-day streak going'),
      _notif(ctx, Icons.favorite, 'Léa liked your post', '${s.cat} mastered Sit'),
      _notif(ctx, Icons.emoji_events_outlined, 'You\'re ${s.myRank}${ordinal(s.myRank)} in ${tierNames[s.league]} League',
          'Finish top 3 by Sunday to reach ${s.nextLeague}'),
      ButtonRow([
        Pill('Preview a reminder', ghost: true, onPressed: () {
          Navigator.pop(ctx);
          openReminderPreview(context);
        }),
      ]),
    ]);
  });
}

/* ---------------- profile ---------------- */

void showInviteSheet(BuildContext context) {
  const code = 'HNY-4821';
  showSheet(context, (ctx) {
    final c = ctx.c;
    return SheetBody(children: [
      const SheetTitle('Invite your family'),
      Text('Share this code. They enter it after installing CATalysts.', style: TextStyle(color: c.muted)),
      CardBox(
        child: Center(
          child: SelectableText(code,
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700, letterSpacing: 5, color: c.accent)),
        ),
      ),
      ButtonRow([
        Pill('Done', ghost: true, onPressed: () => Navigator.pop(ctx)),
        Pill('Copy code', onPressed: () async {
          await Clipboard.setData(const ClipboardData(text: code));
          if (ctx.mounted) toast(ctx, 'Code copied');
        }),
      ]),
    ]);
  });
}

void showLearnSheet(BuildContext context) {
  showSheet(context, (ctx) {
    final c = ctx.c;
    return SheetBody(children: [
      const SheetTitle('The research behind your results'),
      for (final src in researchSources)
        Material(
          color: c.card,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => launchUrl(Uri.parse(src.$2), mode: LaunchMode.externalApplication),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.open_in_new, size: 20, color: c.accent),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(src.$1, style: TextStyle(fontWeight: FontWeight.w600, color: c.accent)),
                    const SizedBox(height: 2),
                    Text(src.$3, style: TextStyle(fontSize: 12, color: c.muted, height: 1.45)),
                  ]),
                ),
              ]),
            ),
          ),
        ),
      Text('Your percentages come from your own check-ins and are not a medical measurement.',
          style: TextStyle(fontSize: 12, color: c.muted)),
      ButtonRow([Pill('Close', onPressed: () => Navigator.pop(ctx))]),
    ]);
  });
}

void showResurveySheet(BuildContext context) {
  showSheet(context, (ctx) {
    final s = ctx.s;
    return SheetBody(children: [
      const SheetTitle('Monthly check'),
      Text('How have you felt over the past two weeks?', style: TextStyle(color: ctx.c.muted)),
      for (final m in metrics)
        LabeledSlider(label: m.$2, value: s.latest[m.$1], onChanged: (v) => s.update(() => s.latest[m.$1] = v)),
      ButtonRow([
        Pill('Save', onPressed: () {
          Navigator.pop(ctx);
          s.update(() {
            s.tab = AppTab.profile;
            s.profileTab = 2;
          });
          toast(context, 'Survey saved');
        }),
      ]),
    ]);
  });
}

/* ---------------- camera ---------------- */

List<Widget> cameraOptions(BuildContext context, AppState s) => [
      SelectTile(
        icon: Icons.photo_camera_outlined,
        title: 'This phone\'s camera',
        subtitle: 'Prop the phone at cat height, about 1 m away',
        selected: s.camSource == CameraSource.phone,
        onTap: () => s.update(() => s.camSource = CameraSource.phone),
      ),
      SelectTile(
        icon: Icons.videocam_outlined,
        title: 'Pet camera',
        subtitle: s.petcamConnected ? 'Living room PetCam · connected' : 'Connect a Wi-Fi pet camera',
        selected: s.camSource == CameraSource.petcam,
        onTap: () {
          if (s.petcamConnected) {
            s.update(() => s.camSource = CameraSource.petcam);
          } else {
            showPairSheet(context);
          }
        },
      ),
    ];

void showCameraSheet(BuildContext context) {
  showSheet(context, (ctx) {
    final s = ctx.s;
    return SheetBody(children: [
      const SheetTitle('Coaching camera'),
      ...cameraOptions(ctx, s),
      ButtonRow([Pill('Done', onPressed: () => Navigator.pop(ctx))]),
    ]);
  });
}

/// Simulated Wi-Fi discovery. Replace with your pet camera vendor's SDK or an
/// RTSP/ONVIF discovery step.
void showPairSheet(BuildContext context) {
  showSheet(context, (ctx) => const _PairSheet());
}

class _PairSheet extends StatefulWidget {
  const _PairSheet();
  @override
  State<_PairSheet> createState() => _PairSheetState();
}

class _PairSheetState extends State<_PairSheet> {
  bool found = false;
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1300), () {
      if (mounted) setState(() => found = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s, c = context.c;
    return SheetBody(children: [
      const SheetTitle('Connect a pet camera'),
      Text(found ? 'Found: Living room PetCam (1080p, night vision).' : 'Searching your Wi-Fi network…',
          style: TextStyle(color: c.muted)),
      const Hero92(Icons.videocam_outlined),
      if (!found) const Center(child: SizedBox(width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 3))),
      if (found)
        ButtonRow([
          Pill('Connect', onPressed: () {
            s.update(() {
              s.petcamConnected = true;
              s.camSource = CameraSource.petcam;
            });
            toast(context, 'PetCam connected');
            Navigator.pop(context);
          }),
        ]),
    ]);
  }
}

/* ---------------- sharing ---------------- */

Future<void> showComposeSheet(BuildContext context, {String? caption, String? achievement}) {
  return showSheet(context, (ctx) => ComposeSheet(caption: caption, achievement: achievement));
}

class ComposeSheet extends StatefulWidget {
  final String? caption, achievement;
  const ComposeSheet({super.key, this.caption, this.achievement});
  @override
  State<ComposeSheet> createState() => _ComposeSheetState();
}

class _ComposeSheetState extends State<ComposeSheet> {
  late final TextEditingController _cap;
  Uint8List? _image;

  @override
  void initState() {
    super.initState();
    final s = context.sr;
    _cap = TextEditingController(text: widget.caption ?? 'Training ${s.lesson.trick} with ${s.cat}.');
  }

  @override
  void dispose() {
    _cap.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
      if (x == null) return;
      final bytes = await x.readAsBytes();
      if (mounted) setState(() => _image = bytes);
    } catch (e) {
      if (mounted) toast(context, 'Could not open photos: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s, c = context.c;
    return SheetBody(children: [
      const SheetTitle('Share with friends'),
      ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: AspectRatio(
          aspectRatio: 4 / 3,
          child: _image != null
              ? Image.memory(_image!, fit: BoxFit.cover)
              : CustomPaint(painter: CatPhotoPainter(260), size: Size.infinite),
        ),
      ),
      Pill(_image == null ? 'Add a photo' : 'Change photo', ghost: true, icon: Icons.photo_library_outlined, onPressed: _pick),
      TextField(
        controller: _cap,
        maxLines: 3,
        decoration: InputDecoration(
          filled: true,
          fillColor: c.card,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: c.line)),
        ),
      ),
      ButtonRow([
        Pill('Cancel', ghost: true, onPressed: () => Navigator.pop(context)),
        Pill('Post', onPressed: () {
          s.addPost(
            caption: _cap.text.trim().isEmpty ? 'Training with ${s.cat}' : _cap.text.trim(),
            achievement: widget.achievement ?? '${s.streak}-day streak',
            image: _image,
          );
          toast(context, 'Shared with friends');
          Navigator.pop(context);
        }),
      ]),
    ]);
  }
}
