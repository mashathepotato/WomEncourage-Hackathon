import 'package:flutter/material.dart';

import '../flows/sheets.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/painters.dart';

class CommunityScreen extends StatelessWidget {
  const CommunityScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final body = switch (s.communityTab) {
      0 => _feed(context, s),
      1 => _nearby(context, s),
      _ => _league(context, s),
    };
    return ListView(padding: const EdgeInsets.all(16), children: [
      Segmented(
        labels: const ['Feed', 'Nearby', 'League'],
        index: s.communityTab,
        onChanged: (i) => s.update(() => s.communityTab = i),
      ),
      const SizedBox(height: 16),
      ...vspaced(body, 16),
    ]);
  }

  /* ---------------- feed ---------------- */

  List<Widget> _feed(BuildContext context, AppState s) {
    final c = context.c;
    return [
      CardBox(
        child: Row(children: [
          const Avatar(),
          const SizedBox(width: 12),
          Expanded(
            child: Material(
              color: c.screen,
              borderRadius: BorderRadius.circular(12),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => showComposeSheet(context),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                  child: Muted('Share ${s.cat}\'s progress…', size: 14),
                ),
              ),
            ),
          ),
        ]),
      ),
      CardBox(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const H2('People you may know', size: 15),
          for (var i = 0; i < s.suggestions.length; i++)
            _personRow(
              c,
              name: s.suggestions[i].name,
              sub: 'Owner of ${s.suggestions[i].cat} · 2 mutual friends',
              last: i == s.suggestions.length - 1,
              action: Pill(
                s.suggestions[i].requested ? 'Requested' : 'Add',
                small: true,
                ghost: s.suggestions[i].requested,
                onPressed: s.suggestions[i].requested
                    ? null
                    : () {
                        s.update(() => s.suggestions[i].requested = true);
                        toast(context, 'Friend request sent to ${s.suggestions[i].name}');
                      },
              ),
            ),
        ]),
      ),
      for (final p in s.posts) PostCard(key: ValueKey(p.id), post: p),
    ];
  }

  /* ---------------- nearby ---------------- */

  List<Widget> _nearby(BuildContext context, AppState s) {
    final c = context.c;
    if (!s.nearbyAllowed) {
      return [
        CardBox(
          padding: const EdgeInsets.fromLTRB(18, 28, 18, 28),
          child: Column(
            children: vspaced([
              const Hero92(Icons.location_on_outlined),
              const H2('Meet cat owners nearby'),
              const Muted(
                  'See which neighbours also train their cats and say hello. Others only see your approximate area, never your address.',
                  align: TextAlign.center),
              Pill('Allow approximate location',
                  onPressed: () => s.update(() {
                        s.nearbyAllowed = true;
                        s.settings['location'] = true;
                      })),
              Pill('Not now', ghost: true, small: true, onPressed: () => s.update(() => s.communityTab = 0)),
            ], 12),
          ),
        ),
      ];
    }
    final sel = s.selectedPin == null ? null : neighbours[s.selectedPin!];
    void hello(Neighbour n) => toast(context, 'You said hello to ${n.name}');
    return [
      ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: AspectRatio(
          aspectRatio: 340 / 250,
          child: LayoutBuilder(builder: (context, box) {
            final scale = box.maxWidth / 340;
            return GestureDetector(
              onTapUp: (d) {
                final p = d.localPosition / scale;
                for (var i = 0; i < neighbours.length; i++) {
                  if ((neighbours[i].pos - p).distance < 24) {
                    s.update(() => s.selectedPin = i);
                    return;
                  }
                }
              },
              child: CustomPaint(painter: MapPainter(c, s.selectedPin), size: Size.infinite),
            );
          }),
        ),
      ),
      if (sel != null)
        CardBox(
          child: Row(children: [
            const Avatar(),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(sel.friend ? '${sel.name} · friend' : sel.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                Muted('${sel.cats} · about ${sel.dist} away', size: 12),
              ]),
            ),
            Pill('Say hello', small: true, onPressed: () => hello(sel)),
          ]),
        )
      else
        const Muted('Tap a cat to see who lives nearby. Circles show approximate areas.'),
      CardBox(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          H2('${neighbours.length} cat owners within 1.5 km', size: 15),
          for (var i = 0; i < neighbours.length; i++)
            _personRow(c,
                name: neighbours[i].name,
                sub: '${neighbours[i].cats} · ${neighbours[i].dist}',
                last: i == neighbours.length - 1,
                action: Pill('Say hello', small: true, ghost: true, onPressed: () => hello(neighbours[i]))),
        ]),
      ),
      CardBox(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: vspaced([
            const H2('Neighbourhood meetup', size: 15),
            const Muted('Saturday 4 Oct, 10:00 at Jardin des Tilleuls. Owners swap tips, cats stay home. 8 going.'),
            ButtonRow([
              Pill(s.meetupGoing ? 'Going' : 'I\'m going',
                  small: true,
                  onPressed: s.meetupGoing
                      ? null
                      : () {
                          s.update(() => s.meetupGoing = true);
                          toast(context, 'See you Saturday');
                        }),
            ]),
          ], 10),
        ),
      ),
    ];
  }

  /* ---------------- league ---------------- */

  List<Widget> _league(BuildContext context, AppState s) {
    final c = context.c;
    final b = s.board;
    final rows = <Widget>[];
    for (var i = 0; i < b.length; i++) {
      if (i == 3) rows.add(_zone('Promotion zone above', c.ok));
      if (i == b.length - 2) rows.add(_zone('Demotion zone below', c.bad));
      final r = b[i];
      rows.add(Container(
        margin: const EdgeInsets.symmetric(vertical: 2),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(color: r.$3 ? c.soft : null, borderRadius: BorderRadius.circular(10)),
        child: Row(children: [
          SizedBox(
              width: 24,
              child: Text('${i + 1}', style: TextStyle(fontWeight: FontWeight.w700, color: c.muted))),
          const Avatar(size: 30),
          const SizedBox(width: 10),
          Expanded(
            child: Text(r.$3 ? 'You and ${s.cat}' : r.$1,
                style: TextStyle(fontWeight: r.$3 ? FontWeight.w600 : FontWeight.w400)),
          ),
          Text('${r.$2} XP', style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
      ));
    }
    return [
      CardBox(
        child: Column(children: [
          Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            for (var i = 0; i < tierNames.length; i++)
              Expanded(
                child: Opacity(
                  opacity: i > s.league ? .45 : 1,
                  child: Column(children: [
                    TierShield(size: i == s.league ? 48 : 32, color: tierColors[i]),
                    const SizedBox(height: 4),
                    Text(tierNames[i],
                        style: TextStyle(
                            fontSize: 10, fontWeight: FontWeight.w600, color: i == s.league ? c.ink : c.muted)),
                  ]),
                ),
              ),
          ]),
          const SizedBox(height: 12),
          Text('${tierNames[s.league]} League', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          Muted('Top 3 move up to ${s.nextLeague} on Sunday · ends in 4 days', align: TextAlign.center),
        ]),
      ),
      CardBox(padding: const EdgeInsets.all(10), child: Column(children: rows)),
      const Muted('Earn XP from training reps, quizzes and daily streaks. Camera-scored reps earn a bonus for accuracy.'),
    ];
  }

  Widget _zone(String t, Color col) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Center(
          child: Text(t.toUpperCase(),
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: .6, color: col)),
        ),
      );

  Widget _personRow(AppColors c, {required String name, required String sub, required Widget action, bool last = false}) =>
      Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(border: last ? null : Border(bottom: BorderSide(color: c.line))),
        child: Row(children: [
          const Avatar(),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
              Text(sub, style: TextStyle(fontSize: 12, color: c.muted)),
            ]),
          ),
          action,
        ]),
      );
}

class PostCard extends StatefulWidget {
  final Post post;
  const PostCard({super.key, required this.post});
  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  final _comment = TextEditingController();

  @override
  void dispose() {
    _comment.dispose();
    super.dispose();
  }

  void _send(AppState s) {
    final t = _comment.text.trim();
    if (t.isEmpty) return;
    s.addComment(widget.post, t);
    _comment.clear();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s, c = context.c, p = widget.post;
    Widget act(IconData icon, String label, Color color, VoidCallback onTap) => InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: const EdgeInsets.all(4),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(icon, size: 20, color: color),
              const SizedBox(width: 6),
              Text(label, style: TextStyle(color: color)),
            ]),
          ),
        );
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Container(
        color: c.card,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            child: Row(children: [
              const Avatar(),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  RichText(
                    text: TextSpan(style: DefaultTextStyle.of(context).style, children: [
                      TextSpan(text: p.who, style: const TextStyle(fontWeight: FontWeight.w600)),
                      TextSpan(text: '  with ${p.cat}', style: TextStyle(color: c.muted, fontSize: 13)),
                    ]),
                  ),
                  Muted(p.time, size: 12),
                ]),
              ),
            ]),
          ),
          AspectRatio(
            aspectRatio: 4 / 3,
            child: p.image != null
                ? Image.memory(p.image!, fit: BoxFit.cover)
                : CustomPaint(painter: CatPhotoPainter(p.hue), size: Size.infinite),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 14, 0),
            child: Row(children: [
              act(p.liked ? Icons.favorite : Icons.favorite_border, '${p.likes}', p.liked ? c.bad : c.ink,
                  () => s.toggleLike(p)),
              const SizedBox(width: 12),
              act(Icons.chat_bubble_outline, '${p.comments.length}', c.ink, () => s.update(() => p.open = !p.open)),
            ]),
          ),
          Padding(padding: const EdgeInsets.fromLTRB(14, 6, 14, 8), child: Text(p.caption)),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: c.soft, borderRadius: BorderRadius.circular(999)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.emoji_events, size: 14, color: c.accent),
                const SizedBox(width: 6),
                Text(p.achievement, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: c.accent)),
              ]),
            ),
          ),
          if (p.open)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                for (final cm in p.comments)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: RichText(
                      text: TextSpan(style: DefaultTextStyle.of(context).style.copyWith(fontSize: 13), children: [
                        TextSpan(text: '${cm.$1} ', style: const TextStyle(fontWeight: FontWeight.w600)),
                        TextSpan(text: cm.$2),
                      ]),
                    ),
                  ),
                Row(children: [
                  Expanded(
                    child: TextField(
                      controller: _comment,
                      onSubmitted: (_) => _send(s),
                      style: const TextStyle(fontSize: 13),
                      decoration: InputDecoration(
                        hintText: 'Add a comment',
                        isDense: true,
                        filled: true,
                        fillColor: c.screen,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(999), borderSide: BorderSide(color: c.line)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Pill('Post', small: true, onPressed: () => _send(s)),
                ]),
              ]),
            ),
        ]),
      ),
    );
  }
}
