import 'package:flutter/material.dart';

import '../flows/sheets.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'home.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});
  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  final _q = TextEditingController();
  String? _open;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    final q = _q.text.trim().toLowerCase();
    const categories = [
      ('Exercises', Icons.accessibility_new),
      ('Games', Icons.toys),
      ('Good Manners', Icons.emoji_nature),
      ('Blogs', Icons.article_outlined),
    ];
    final sections = <Widget>[];
    for (final (name, icon) in categories) {
      final items = name == 'Blogs'
          ? [
              for (final b in blogs)
                if (b.$1.toLowerCase().contains(q)) _item(c, b.$1, b.$2, () => showBlogSheet(context, b.$1)),
            ]
          : [
              for (final t in tricks.values)
                if (t.category == name && t.name.toLowerCase().contains(q))
                  _item(c, t.name, '${t.mins} min', () => showTrickSheet(context, t.id)),
            ];
      if (q.isNotEmpty && items.isEmpty) continue;
      final open = _open == name || q.isNotEmpty;
      sections.add(Container(
        decoration: BoxDecoration(border: Border(bottom: BorderSide(color: c.line, width: 3))),
        child: Column(children: [
          InkWell(
            onTap: () => setState(() => _open = _open == name ? null : name),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(children: [
                SizedBox(width: 50, child: Icon(icon, size: 34, color: c.ink)),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(name, style: TextStyle(fontSize: 21, fontWeight: FontWeight.w600, color: c.accent)),
                ),
                AnimatedRotation(
                  turns: open ? .25 : 0,
                  duration: const Duration(milliseconds: 200),
                  child: Icon(Icons.chevron_right, color: c.accent),
                ),
              ]),
            ),
          ),
          if (open)
            Padding(
              padding: const EdgeInsets.only(left: 64, bottom: 12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: vspaced(items, 6)),
            ),
        ]),
      ));
    }
    return ListView(padding: const EdgeInsets.all(16), children: [
      TextField(
        controller: _q,
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(
          hintText: 'Search tricks and articles',
          prefixIcon: const Icon(Icons.search),
          filled: true,
          fillColor: c.card,
          isDense: true,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 12),
      if (sections.isEmpty) const Muted('Nothing matches that search. Try "sit" or "games".') else ...sections,
      const SizedBox(height: 20),
      const H2('Recently Viewed'),
      const SizedBox(height: 12),
      const RecentTiles(),
    ]);
  }

  Widget _item(AppColors c, String title, String meta, VoidCallback onTap) => Material(
        color: c.card,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            child: Row(children: [
              Expanded(child: Text(title, style: const TextStyle(fontSize: 14))),
              const SizedBox(width: 8),
              Text(meta, style: TextStyle(fontSize: 12, color: c.muted)),
            ]),
          ),
        ),
      );
}
