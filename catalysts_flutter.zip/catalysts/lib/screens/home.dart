import 'dart:math';

import 'package:flutter/material.dart';

import '../flows/lesson_flow.dart';
import '../flows/sheets.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _pc = PageController(initialPage: 1);
  int _slide = 1;

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s, c = context.c;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: vspaced([
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Container(
            height: 226,
            color: c.accent,
            child: PageView(
              controller: _pc,
              onPageChanged: (i) => setState(() => _slide = i),
              children: [_dailyGoal(s, c), _streak(s, c), _wellbeing(s, c)],
            ),
          ),
        ),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (var i = 0; i < 3; i++)
            GestureDetector(
              onTap: () => _pc.animateToPage(i, duration: const Duration(milliseconds: 300), curve: Curves.easeOut),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 5),
                width: 12,
                height: 12,
                decoration: BoxDecoration(shape: BoxShape.circle, color: i == _slide ? c.accent : c.line),
              ),
            ),
        ]),
        const LessonCard(),
        _leagueCard(s, c),
        const H2('Recently Viewed'),
        const RecentTiles(),
      ], 18),
    );
  }

  Widget _frame(AppColors c, String title, List<Widget> body) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: c.accentInk)),
          const SizedBox(height: 10),
          ...body,
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (var i = 0; i < 5; i++)
                Icon(Icons.pets, size: i == 2 ? 34 : 26, color: c.accentInk.withOpacity(i == 2 ? 1 : .7)),
            ],
          ),
          const SizedBox(height: 6),
        ]),
      );

  Widget _slideButton(AppColors c, String label, VoidCallback onTap) => Align(
        alignment: Alignment.centerRight,
        child: Material(
          color: c.accentInk,
          borderRadius: BorderRadius.circular(6),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(6),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 4),
              child: Text(label, style: TextStyle(color: c.accent, fontWeight: FontWeight.w500)),
            ),
          ),
        ),
      );

  Widget _dailyGoal(AppState s, AppColors c) => _frame(c, 'Daily Goal', [
        RichText(
            text: TextSpan(style: TextStyle(color: c.accentInk), children: [
          TextSpan(text: '${s.todayMins}', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w700)),
          const TextSpan(text: ' / 10 min', style: TextStyle(fontSize: 18)),
        ])),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(5),
          child: LinearProgressIndicator(
            value: min(1.0, s.todayMins / 10),
            minHeight: 10,
            color: c.accentInk,
            backgroundColor: c.accentInk.withOpacity(.3),
          ),
        ),
        const SizedBox(height: 8),
        Text('Two 5-minute sessions keep ${s.cat} interested.', style: TextStyle(color: c.accentInk, fontSize: 13)),
      ]);

  Widget _streak(AppState s, AppColors c) {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Today'];
    return _frame(c, 'Training Streak', [
      Row(children: [
        for (var i = 0; i < 7; i++)
          Expanded(
            child: Column(children: [
              Text(days[i], style: TextStyle(fontSize: 11, color: c.accentInk)),
              const SizedBox(height: 4),
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: s.week[i] ? c.accentInk : Colors.transparent,
                  border: Border.all(color: c.accentInk, width: 2),
                ),
                child: Icon(s.week[i] ? Icons.event_available : Icons.calendar_today_outlined,
                    size: 16, color: s.week[i] ? c.accent : c.accentInk),
              ),
            ]),
          ),
      ]),
      const SizedBox(height: 10),
      _slideButton(c, 'More', () => s.update(() {
            s.tab = AppTab.profile;
            s.profileTab = 0;
          })),
    ]);
  }

  Widget _wellbeing(AppState s, AppColors c) => _frame(c, 'Your Wellbeing', [
        RichText(
            text: TextSpan(style: TextStyle(color: c.accentInk), children: [
          TextSpan(text: '−${s.stressDropSinceStart}%', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w700)),
          const TextSpan(text: ' stress', style: TextStyle(fontSize: 16)),
        ])),
        Text('Since you joined, based on your check-ins.', style: TextStyle(color: c.accentInk, fontSize: 13)),
        const SizedBox(height: 8),
        _slideButton(c, 'See details', () => s.update(() {
              s.tab = AppTab.profile;
              s.profileTab = 2;
            })),
      ]);

  Widget _leagueCard(AppState s, AppColors c) => CardBox(
        child: Row(children: [
          TierShield(size: 40, color: tierColors[s.league]),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${tierNames[s.league]} League', style: const TextStyle(fontWeight: FontWeight.w600)),
              Muted('${s.myRank}${ordinal(s.myRank)} place · ${s.weekXp} XP this week'),
            ]),
          ),
          Pill('View',
              ghost: true,
              small: true,
              onPressed: () => s.update(() {
                    s.tab = AppTab.community;
                    s.communityTab = 2;
                  })),
        ]),
      );
}

class LessonCard extends StatelessWidget {
  const LessonCard({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.s, c = context.c, l = s.lesson;
    Widget step(bool done, String t) => Row(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(shape: BoxShape.circle, color: done ? c.accent : c.soft),
            child: done ? Icon(Icons.check, size: 14, color: c.accentInk) : null,
          ),
          const SizedBox(width: 6),
          Text(t, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: c.muted)),
        ]);
    return CardBox(
      child: Column(
        children: vspaced([
          Text('Lesson ${l.n}', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w600, color: c.accent)),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            step(l.quiz, 'Quiz'),
            step(l.training, 'Training'),
            step(l.activity, 'Activity'),
          ]),
          const Hero92(Icons.pets),
          Text(l.trick, style: const TextStyle(fontWeight: FontWeight.w600)),
          Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(s.usingPetcam ? Icons.videocam_outlined : Icons.photo_camera_outlined, size: 16, color: c.muted),
            const SizedBox(width: 6),
            Muted('Coached by ${s.camLabel}', size: 12),
          ]),
          Pill(l.done == 3 ? 'Start next lesson' : (l.done > 0 ? 'Continue' : 'Start'),
              onPressed: () => openLessonFlow(context)),
        ], 12),
      ),
    );
  }
}

class RecentTiles extends StatelessWidget {
  const RecentTiles({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.s, c = context.c;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: hspaced([
        for (final id in s.recent.take(3))
          Expanded(
            child: Material(
              color: c.card,
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => showTrickSheet(context, id),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(6, 16, 6, 12),
                  child: Column(children: [
                    Badge58(tricks[id]!.icon),
                    const SizedBox(height: 8),
                    Text(tricks[id]!.name,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        style: TextStyle(color: c.accent, fontSize: 14, fontWeight: FontWeight.w500)),
                  ]),
                ),
              ),
            ),
          ),
      ], 12),
    );
  }
}
