import 'package:flutter/material.dart';

import '../flows/sheets.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/painters.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final body = switch (s.profileTab) {
      0 => _progress(context, s),
      1 => _health(context, s),
      _ => _wellbeing(context, s),
    };
    return ListView(padding: const EdgeInsets.all(16), children: [
      UnderlineTabs(
        labels: const ['Progress', 'Health', 'Wellbeing'],
        index: s.profileTab,
        onChanged: (i) => s.update(() => s.profileTab = i),
      ),
      const SizedBox(height: 18),
      ...vspaced(body, 16),
    ]);
  }

  List<Widget> _progress(BuildContext context, AppState s) {
    final c = context.c;
    final l = s.lesson;
    final learned = [
      ('Sit', 'Mastered'),
      ('Kiss', 'Mastered'),
      ('High Five', l.n > 3 ? 'Mastered' : '${l.done}/3 steps'),
      ('Fetch', l.n > 4 ? 'Mastered' : (l.n == 4 ? '${l.done}/3 steps' : 'Not started')),
    ];
    return [
      StatTriple([
        ('${s.streak}', 'Current streak'),
        ('${s.longest > s.streak ? s.longest : s.streak}', 'Longest streak'),
        ('${s.minutes ~/ 60}h ${s.minutes % 60}m', 'Time trained'),
      ]),
      CardBox(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            const Expanded(child: H2('Minutes per week', size: 15)),
            Muted('${s.weekHist.last} min this week', size: 12),
          ]),
          const SizedBox(height: 8),
          AspectRatio(aspectRatio: 300 / 120, child: CustomPaint(painter: WeekBarsPainter(s.weekHist, c))),
        ]),
      ),
      CardBox(
        child: Column(
          children: vspaced([
            Pill('Invite your family', onPressed: () => showInviteSheet(context)),
            Icon(Icons.family_restroom, size: 84, color: c.accent),
            Muted('Everyone who trains ${s.cat} adds to the same streak.', align: TextAlign.center),
          ], 12),
        ),
      ),
      CardBox(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const H2('Tricks learned', size: 15),
          for (var i = 0; i < learned.length; i++)
            InfoRow(
              title: learned[i].$1,
              last: i == learned.length - 1,
              trailing: Text(learned[i].$2,
                  style: TextStyle(fontSize: 13, color: learned[i].$2 == 'Mastered' ? c.ok : c.muted)),
            ),
        ]),
      ),
    ];
  }

  List<Widget> _health(BuildContext context, AppState s) {
    final c = context.c;
    return [
      CardBox(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          InfoRow(
              title: 'Weight',
              trailing: Text('${s.weight.last.toStringAsFixed(1)} kg', style: const TextStyle(fontWeight: FontWeight.w600))),
          const SizedBox(height: 8),
          AspectRatio(aspectRatio: 320 / 130, child: CustomPaint(painter: WeightPainter(s.weight, c))),
          const SizedBox(height: 8),
          ButtonRow([
            Pill('Log weight', ghost: true, small: true, onPressed: () {
              s.logWeight();
              toast(context, 'Weight logged');
            }),
          ]),
        ]),
      ),
      CardBox(
        child: Column(children: [
          InfoRow(title: 'Next vet visit', trailing: const Text('14 Oct 2026', style: TextStyle(fontWeight: FontWeight.w600))),
          InfoRow(
              title: 'Vaccinations',
              trailing: Text('Up to date', style: TextStyle(fontWeight: FontWeight.w600, color: c.ok))),
          InfoRow(
              title: 'Activity from camera',
              last: true,
              trailing: const Text('34 min/day', style: TextStyle(fontWeight: FontWeight.w600))),
        ]),
      ),
    ];
  }

  List<Widget> _wellbeing(BuildContext context, AppState s) {
    final c = context.c;
    Widget bar(String k, String label, bool lowerBetter) {
      final d = s.latest[k] - s.baseline[k];
      final good = lowerBetter ? d < 0 : d > 0;
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Expanded(child: Text(label, style: const TextStyle(fontSize: 14))),
          Text('${d > 0 ? '+' : ''}$d pts',
              style: TextStyle(fontSize: 14, color: good ? c.ok : c.muted, fontWeight: good ? FontWeight.w600 : null)),
        ]),
        const SizedBox(height: 4),
        HoldBar(value: s.baseline[k] / 100, height: 8, opacity: .3),
        const SizedBox(height: 4),
        HoldBar(value: s.latest[k] / 100, height: 8),
      ]);
    }

    return [
      CardBox(
        child: Column(
          children: vspaced([
            const Muted('Average stress drop per session'),
            Text('−${s.avgSessionDrop}%', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w700, color: c.accent)),
            Muted('From your before-and-after check-ins over ${s.checkins.length} sessions.', align: TextAlign.center),
            Pill('Learn more about the research', ghost: true, small: true, onPressed: () => showLearnSheet(context)),
          ], 8),
        ),
      ),
      CardBox(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const H2('Stress before and after each session', size: 15),
          const SizedBox(height: 8),
          AspectRatio(aspectRatio: 300 / 120, child: CustomPaint(painter: StressPainter(s.checkins, c))),
          const SizedBox(height: 6),
          Row(children: [
            Icon(Icons.circle_outlined, size: 12, color: c.accent),
            const SizedBox(width: 4),
            const Muted('Before', size: 12),
            const SizedBox(width: 14),
            Icon(Icons.circle, size: 12, color: c.accent),
            const SizedBox(width: 4),
            const Muted('After', size: 12),
          ]),
        ]),
      ),
      CardBox(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: vspaced([
            const Row(children: [Expanded(child: H2('Since you joined', size: 15)), Muted('faint bar: first survey', size: 12)]),
            for (final m in metrics) bar(m.$1, m.$2, m.$3),
            ButtonRow([Pill('Retake monthly survey', ghost: true, small: true, onPressed: () => showResurveySheet(context))]),
          ], 12),
        ),
      ),
      const FeedbackTile(
        good: true,
        title: 'Recommendation',
        body: 'Your biggest drops came from evening sessions after 18:00. We moved your reminder to 18:30.',
      ),
      const Muted('Self-reported check-ins, not a medical assessment.', size: 12),
    ];
  }
}
