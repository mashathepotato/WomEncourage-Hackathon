import 'package:flutter/material.dart';

import '../flows/onboarding.dart';
import '../flows/reminder_preview.dart';
import '../flows/sheets.dart';
import '../services/reminders.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/common.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s, c = context.c;
    Widget sw(String key, String title, String sub, {bool last = false, ValueChanged<bool>? after}) => InfoRow(
          title: title,
          subtitle: sub,
          last: last,
          trailing: Switch(
            value: s.settings[key] ?? false,
            onChanged: (v) {
              s.update(() => s.settings[key] = v);
              after?.call(v);
            },
          ),
        );
    return ListView(
      padding: const EdgeInsets.all(16),
      children: vspaced([
        CardBox(
          child: Column(children: [
            sw('reminders', 'Training reminders', 'A daily nudge, even when you are in other apps', after: (v) {
              if (v) {
                Reminders.enableDaily('${s.cat} is waiting!', 'Five minutes keeps your ${s.streak}-day streak alive.');
              } else {
                Reminders.disableDaily();
              }
            }),
            sw('sounds', 'Clicker sound', 'Plays when a rep reaches its target'),
            sw('weekly', 'Weekly summary', 'Sent on Sundays', last: true),
          ]),
        ),
        CardBox(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const H2('Camera', size: 15),
            InfoRow(
              title: 'Coaching camera',
              subtitle: s.camLabel,
              trailing: Pill('Change', ghost: true, small: true, onPressed: () => showCameraSheet(context)),
            ),
            InfoRow(
              title: 'Pet camera',
              subtitle: s.petcamConnected ? 'Living room PetCam · connected' : 'Not connected',
              last: true,
              trailing: Pill(
                s.petcamConnected ? 'Disconnect' : 'Connect',
                ghost: true,
                small: true,
                onPressed: s.petcamConnected
                    ? () {
                        s.update(() {
                          s.petcamConnected = false;
                          s.camSource = CameraSource.phone;
                        });
                        toast(context, 'PetCam disconnected');
                      }
                    : () => showPairSheet(context),
              ),
            ),
          ]),
        ),
        CardBox(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const H2('Privacy', size: 15),
            sw('location', 'Show me on the Nearby map', 'Approximate area only', after: (v) {
              if (!v) s.update(() => s.nearbyAllowed = false);
            }),
            sw('shareProgress', 'Share milestones with friends', 'Streaks, leagues and mastered tricks', last: true),
          ]),
        ),
        CardBox(
          child: Column(children: [
            InfoRow(
              title: 'Preview a reminder',
              subtitle: 'Shows how the nudge looks over another app',
              trailing: Pill('Preview', ghost: true, small: true, onPressed: () => openReminderPreview(context)),
            ),
            InfoRow(
              title: 'Send a real test notification',
              subtitle: Reminders.supported ? 'Arrives even if you leave the app' : 'Available on Android and iOS',
              trailing: Pill('Send',
                  ghost: true,
                  small: true,
                  onPressed: () async {
                    final ok = await Reminders.showNow(
                        'CATalysts', '${s.cat} is waiting! You haven\'t trained today. Do it now?');
                    if (context.mounted) toast(context, ok ? 'Notification sent' : 'Notifications need Android or iOS');
                  }),
            ),
            InfoRow(
                title: 'Wellbeing survey',
                trailing: Pill('Retake', ghost: true, small: true, onPressed: () => showResurveySheet(context))),
            InfoRow(
                title: 'Onboarding',
                trailing: Pill('Replay', ghost: true, small: true, onPressed: () => openOnboarding(context))),
            InfoRow(
              title: 'Reset demo',
              last: true,
              trailing: Pill('Reset', ghost: true, small: true, onPressed: () {
                s.reset();
                openOnboarding(context);
              }),
            ),
          ]),
        ),
        Center(child: Text('CATalysts prototype · example data', style: TextStyle(fontSize: 12, color: c.muted))),
      ], 16),
    );
  }
}
