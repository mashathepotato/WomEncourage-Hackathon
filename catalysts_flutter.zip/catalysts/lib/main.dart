import 'dart:async';

import 'package:flutter/material.dart';

import 'flows/lesson_flow.dart';
import 'flows/onboarding.dart';
import 'flows/reminder_preview.dart';
import 'flows/sheets.dart';
import 'screens/community.dart';
import 'screens/home.dart';
import 'screens/library.dart';
import 'screens/profile.dart';
import 'screens/settings.dart';
import 'services/reminders.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets/common.dart';
import 'widgets/painters.dart';

final navKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Reminders.init();
  runApp(CatalystsApp(state: AppState()));
}

class CatalystsApp extends StatelessWidget {
  final AppState state;
  const CatalystsApp({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: state,
      child: MaterialApp(
        title: 'CATalysts',
        debugShowCheckedModeBanner: false,
        navigatorKey: navKey,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        home: const Shell(),
      ),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  Timer? _nudge;

  @override
  void initState() {
    super.initState();
    // Tapping a real OS notification opens the lesson.
    Reminders.onTap = () {
      final ctx = navKey.currentContext;
      if (ctx != null) openLessonFlow(ctx);
    };
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final s = context.sr;
      if (!s.onboarded) openOnboarding(context);
      if (s.settings['reminders'] == true) {
        Reminders.enableDaily('${s.cat} is waiting!', 'Five minutes keeps your streak alive.');
      }
    });
    // In-app demo of the nudge: 40 s after onboarding, if nothing trained today
    // and no sheet is open, show the "other app" reminder once.
    _nudge = Timer.periodic(const Duration(seconds: 3), (_) {
      final s = context.sr;
      final at = s.onboardedAt;
      final nav = navKey.currentState;
      if (at == null || nav == null) return;
      if (!s.reminderShown &&
          !s.week[6] &&
          s.settings['reminders'] == true &&
          DateTime.now().difference(at) > const Duration(seconds: 40) &&
          !nav.canPop()) {
        s.reminderShown = true;
        openReminderPreview(nav.context);
      }
    });
  }

  @override
  void dispose() {
    _nudge?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s, c = context.c;
    final screen = switch (s.tab) {
      AppTab.home => const HomeScreen(),
      AppTab.library => const LibraryScreen(),
      AppTab.community => const CommunityScreen(),
      AppTab.profile => const ProfileScreen(),
      AppTab.settings => const SettingsScreen(),
    };
    return Scaffold(
      backgroundColor: c.screen,
      body: SafeArea(
        bottom: false,
        child: Column(children: [
          const Header(),
          Expanded(child: KeyedSubtree(key: ValueKey(s.tab), child: screen)),
        ]),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: s.tab.index,
        onDestinationSelected: (i) => s.update(() => s.tab = AppTab.values[i]),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        height: 68,
        destinations: [
          const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          const NavigationDestination(
              icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Library'),
          const NavigationDestination(
              icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Friends'),
          NavigationDestination(icon: const Icon(Icons.pets_outlined), selectedIcon: const Icon(Icons.pets), label: s.cat),
          const NavigationDestination(
              icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

class Header extends StatelessWidget {
  const Header({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s, c = context.c;
    const titles = {AppTab.library: 'Library', AppTab.community: 'Community', AppTab.settings: 'Settings'};
    final title = titles[s.tab];
    return Container(
      color: c.card,
      padding: const EdgeInsets.fromLTRB(14, 6, 6, 10),
      child: Row(children: [
        Expanded(
          child: Align(
            alignment: Alignment.centerLeft,
            child: title != null
                ? Text(title, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600, color: c.accent))
                : InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () => showCatPicker(context),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Avatar(),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(s.cat,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: c.accent, fontWeight: FontWeight.w600, fontSize: 15)),
                      ),
                      Icon(Icons.keyboard_arrow_down, color: c.accent),
                    ]),
                  ),
          ),
        ),
        Column(mainAxisSize: MainAxisSize.min, children: [
          CustomPaint(size: const Size(50, 40), painter: LogoPainter(c)),
          const SizedBox(height: 2),
          Text.rich(TextSpan(children: [
            TextSpan(text: 'CAT', style: TextStyle(color: c.accent)),
            TextSpan(text: 'alysts', style: TextStyle(color: c.ink)),
          ]), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
        ]),
        Expanded(
          child: Align(
            alignment: Alignment.centerRight,
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(
                tooltip: 'Clicker',
                visualDensity: VisualDensity.compact,
                icon: Icon(Icons.sports, color: c.ink),
                onPressed: () => playClick(s, force: true),
              ),
              IconButton(
                tooltip: 'Info',
                visualDensity: VisualDensity.compact,
                icon: Icon(Icons.info_outline, color: c.ink),
                onPressed: () => showInfoSheet(context),
              ),
              IconButton(
                tooltip: 'Notifications',
                visualDensity: VisualDensity.compact,
                icon: Badge(
                  isLabelVisible: s.unread > 0,
                  smallSize: 8,
                  backgroundColor: c.bad,
                  child: Icon(Icons.notifications_none, color: c.ink),
                ),
                onPressed: () => showNotificationsSheet(context),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
