import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Colour tokens taken from the original CatKit mockups (purple + lavender).
@immutable
class AppColors extends ThemeExtension<AppColors> {
  final Color bg, screen, card, ink, muted, accent, accentInk, soft, line, ok, warn, bad;

  const AppColors({
    required this.bg,
    required this.screen,
    required this.card,
    required this.ink,
    required this.muted,
    required this.accent,
    required this.accentInk,
    required this.soft,
    required this.line,
    required this.ok,
    required this.warn,
    required this.bad,
  });

  static const light = AppColors(
    bg: Color(0xFFEEEDF5),
    screen: Color(0xFFF6F6FD),
    card: Color(0xFFFFFFFF),
    ink: Color(0xFF26243A),
    muted: Color(0xFF8E8BA3),
    accent: Color(0xFF7B6DBD),
    accentInk: Color(0xFFFFFFFF),
    soft: Color(0xFFE7E3F7),
    line: Color(0xFFD5D9EC),
    ok: Color(0xFF3E9B6A),
    warn: Color(0xFFD9822B),
    bad: Color(0xFFD9546A),
  );

  static const dark = AppColors(
    bg: Color(0xFF121119),
    screen: Color(0xFF1A1924),
    card: Color(0xFF252336),
    ink: Color(0xFFECEAF7),
    muted: Color(0xFFA09DB8),
    accent: Color(0xFF9D90E0),
    accentInk: Color(0xFF17152A),
    soft: Color(0xFF322E4D),
    line: Color(0xFF3A3752),
    ok: Color(0xFF6CC596),
    warn: Color(0xFFEBA35A),
    bad: Color(0xFFEE7C8E),
  );

  @override
  AppColors copyWith() => this;

  @override
  AppColors lerp(ThemeExtension<AppColors>? other, double t) =>
      (t < 0.5 || other is! AppColors) ? this : other;
}

const tierNames = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond'];
const tierColors = [
  Color(0xFFB87A4B),
  Color(0xFF9EA3B5),
  Color(0xFFD7A928),
  Color(0xFF6FA6B8),
  Color(0xFF6C8CF0),
];

ThemeData buildTheme(Brightness brightness) {
  final c = brightness == Brightness.light ? AppColors.light : AppColors.dark;
  final scheme = ColorScheme.fromSeed(seedColor: c.accent, brightness: brightness)
      .copyWith(primary: c.accent, onPrimary: c.accentInk, surface: c.screen);
  final base = ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: scheme,
    scaffoldBackgroundColor: c.screen,
    extensions: [c],
    sliderTheme: SliderThemeData(activeTrackColor: c.accent, thumbColor: c.accent, inactiveTrackColor: c.soft),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? c.accentInk : null),
      trackColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? c.accent : null),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: c.card,
      indicatorColor: c.soft,
      labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(
            fontSize: 11,
            fontWeight: s.contains(WidgetState.selected) ? FontWeight.w600 : FontWeight.w400,
            color: s.contains(WidgetState.selected) ? c.accent : c.muted,
          )),
      iconTheme: WidgetStateProperty.resolveWith(
          (s) => IconThemeData(color: s.contains(WidgetState.selected) ? c.accent : c.muted)),
    ),
  );
  return base.copyWith(
    textTheme: GoogleFonts.poppinsTextTheme(base.textTheme).apply(bodyColor: c.ink, displayColor: c.ink),
  );
}

extension ColorsX on BuildContext {
  AppColors get c => Theme.of(this).extension<AppColors>()!;
}
