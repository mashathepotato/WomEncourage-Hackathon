import 'dart:math';
import 'dart:typed_data';

import 'package:flutter/material.dart';

/* ============================== models ============================== */

enum AppTab { home, library, community, profile, settings }

enum CameraSource { phone, petcam }

class Trick {
  final String id, name, category;
  final int mins;
  final IconData icon;
  const Trick(this.id, this.name, this.category, this.mins, this.icon);
}

const tricks = <String, Trick>{
  'highfive': Trick('highfive', 'High Five', 'Exercises', 5, Icons.pets),
  'kiss': Trick('kiss', 'Kiss', 'Good Manners', 4, Icons.favorite_border),
  'fetch': Trick('fetch', 'Fetch', 'Games', 8, Icons.toys),
  'sit': Trick('sit', 'Sit', 'Good Manners', 3, Icons.pets),
  'spin': Trick('spin', 'Spin', 'Exercises', 5, Icons.pets),
  'jump': Trick('jump', 'Jump Through Hoop', 'Exercises', 10, Icons.pets),
  'chase': Trick('chase', 'Laser Chase', 'Games', 6, Icons.toys),
  'puzzle': Trick('puzzle', 'Treat Puzzle', 'Games', 7, Icons.toys),
  'scratch': Trick('scratch', 'Use the Scratch Post', 'Good Manners', 4, Icons.favorite_border),
  'carrier': Trick('carrier', 'Enter the Carrier', 'Good Manners', 6, Icons.favorite_border),
};

const blogs = [
  ('Why clicker training works on cats', '4 min read'),
  ('Reading your cat’s tail', '3 min read'),
  ('Short sessions beat long ones', '2 min read'),
];

/// (key, goal label, short label)
const goals = [
  ('stress', 'Lower stress', 'Stress'),
  ('anxiety', 'Ease anxiety', 'Anxiety'),
  ('loneliness', 'Feel less lonely', 'Loneliness'),
  ('motivation', 'More motivation', 'Motivation'),
  ('creativity', 'More creativity', 'Creativity'),
];

/// (key, label, lowerIsBetter)
const metrics = [
  ('stress', 'Stress', true),
  ('anxiety', 'Anxiety', true),
  ('loneliness', 'Loneliness', true),
  ('motivation', 'Motivation', false),
  ('creativity', 'Creativity', false),
];

/// (title, url, description)
const researchSources = [
  (
    'NIH News in Health: The Power of Pets',
    'https://newsinhealth.nih.gov/2018/02/power-pets',
    'Summarises research linking time with animals to lower cortisol, lower blood pressure and less loneliness.'
  ),
  (
    'Pendry & Vandagriff (2019), AERA Open',
    'https://journals.sagepub.com/doi/10.1177/2332858419852592',
    'Randomised trial with 249 students: 10 minutes petting cats and dogs lowered cortisol more than watching or waiting.'
  ),
];

class Wellbeing {
  final Map<String, int> v;
  Wellbeing(this.v);
  int operator [](String k) => v[k]!;
  void operator []=(String k, int x) => v[k] = x;
  Wellbeing copy() => Wellbeing(Map.of(v));
}

class CheckIn {
  final String day;
  final int pre, post;
  final int? mood;
  const CheckIn(this.day, this.pre, this.post, [this.mood]);
}

class Post {
  final int id;
  final String who, cat, time, achievement, caption;
  int likes;
  bool liked;
  bool open = false;
  final double hue;
  final Uint8List? image;
  final List<(String, String)> comments;
  Post({
    required this.id,
    required this.who,
    required this.cat,
    required this.time,
    required this.achievement,
    required this.caption,
    required this.likes,
    this.liked = false,
    required this.hue,
    this.image,
    List<(String, String)>? comments,
  }) : comments = comments ?? [];
}

class Suggestion {
  final String name, cat;
  bool requested = false;
  Suggestion(this.name, this.cat);
}

class Neighbour {
  final String name, cats, dist;
  final Offset pos; // in 340x250 map space
  final bool friend;
  const Neighbour(this.name, this.cats, this.dist, this.pos, [this.friend = false]);
}

const neighbours = [
  Neighbour('Léa', 'Mochi', '350 m', Offset(95, 70), true),
  Neighbour('Tom', 'Pixel', '600 m', Offset(250, 60)),
  Neighbour('Amina', 'Nala and Zaza', '450 m', Offset(230, 180)),
  Neighbour('Jules', 'Oscar', '800 m', Offset(60, 190)),
  Neighbour('Clara', 'Minou', '1.1 km', Offset(300, 130)),
];

const leaderboard = [
  ('Sofia', 520),
  ('Karim', 455),
  ('Amina', 410),
  ('Léa', 380),
  ('Tom', 290),
  ('Jules', 240),
  ('Clara', 210),
  ('Marc', 160),
  ('Inès', 120),
];

class Lesson {
  int n;
  String trick;
  bool quiz = false, training = false, activity = false;
  Lesson(this.n, this.trick);
  int get done => [quiz, training, activity].where((x) => x).length;
}

class RepResult {
  final double hold, height;
  final int score;
  const RepResult(this.hold, this.height, this.score);
  bool get clean => hold >= 2.0 && height >= 0.72;
}

class SessionSummary {
  final int mins, accuracy, xp, clean, reps, thisWeek, weekChangePct, rankBefore, rankAfter;
  final double bestHold;
  const SessionSummary({
    required this.mins,
    required this.accuracy,
    required this.xp,
    required this.clean,
    required this.reps,
    required this.thisWeek,
    required this.weekChangePct,
    required this.rankBefore,
    required this.rankAfter,
    required this.bestHold,
  });
}

String ordinal(int n) => n == 1 ? 'st' : n == 2 ? 'nd' : n == 3 ? 'rd' : 'th';

/* ============================== app state ============================== */

/// Single source of truth. All numbers are example data for the prototype.
class AppState extends ChangeNotifier {
  AppState() {
    _seed();
  }

  late AppTab tab;
  late String cat;
  late List<String> cats;
  late int profileTab, communityTab;
  late bool onboarded;
  late Wellbeing baseline, latest;
  late Set<String> goalSet;
  late CameraSource camSource;
  late bool petcamConnected;
  late List<bool> week; // Sun..Today
  late int longest, minutes, todayMins;
  late List<int> weekHist; // minutes per week, current week last
  late int weekXp, league;
  late Lesson lesson;
  late List<String> recent;
  late Map<String, bool> settings;
  late bool nearbyAllowed;
  int? selectedPin;
  late int unread;
  late bool reminderShown;
  late List<double> weight;
  late List<CheckIn> checkins;
  late List<Post> posts;
  late List<Suggestion> suggestions;
  late bool meetupGoing;
  DateTime? onboardedAt;

  void _seed() {
    tab = AppTab.home;
    cat = 'Honey';
    cats = ['Honey', 'Mochi'];
    profileTab = 0;
    communityTab = 0;
    onboarded = false;
    baseline = Wellbeing({'stress': 68, 'anxiety': 60, 'loneliness': 55, 'motivation': 40, 'creativity': 45});
    latest = Wellbeing({'stress': 52, 'anxiety': 49, 'loneliness': 41, 'motivation': 58, 'creativity': 54});
    goalSet = {'stress', 'loneliness'};
    camSource = CameraSource.phone;
    petcamConnected = false;
    week = [true, true, false, true, true, true, false];
    longest = 6;
    minutes = 142;
    todayMins = 0;
    weekHist = [22, 31, 26, 38, 40];
    weekXp = 310;
    league = 2;
    lesson = Lesson(3, 'High Five');
    recent = ['highfive', 'kiss', 'fetch'];
    settings = {'reminders': true, 'sounds': true, 'weekly': false, 'location': false, 'shareProgress': true};
    nearbyAllowed = false;
    selectedPin = null;
    unread = 2;
    reminderShown = false;
    weight = [4.3, 4.3, 4.4, 4.2, 4.3];
    checkins = const [
      CheckIn('2 Sep', 70, 61, 3),
      CheckIn('9 Sep', 66, 60, 2),
      CheckIn('15 Sep', 64, 52, 3),
      CheckIn('21 Sep', 61, 50, 4),
      CheckIn('26 Sep', 58, 49, 3),
      CheckIn('29 Sep', 57, 47, 3),
    ].toList();
    posts = [
      Post(
          id: 1,
          who: 'Léa',
          cat: 'Mochi',
          time: '2 h',
          achievement: 'Mastered Spin',
          caption: 'Took 6 sessions but she finally spins on cue!',
          likes: 14,
          hue: 28,
          comments: [('Karim', 'Amazing, what treats do you use?'), ('Léa', 'Freeze-dried chicken, works every time')]),
      Post(
          id: 2,
          who: 'Karim',
          cat: 'Biscuit',
          time: '5 h',
          achievement: '7-day streak',
          caption: 'One week straight. Biscuit now waits by the mat at 6pm.',
          likes: 9,
          liked: true,
          hue: 200),
      Post(
          id: 3,
          who: 'Sofia',
          cat: 'Luna',
          time: '1 d',
          achievement: 'Reached Platinum league',
          caption: 'Luna and I are on a roll this month.',
          likes: 21,
          hue: 300,
          comments: [('Léa', 'Congrats you two!')]),
    ];
    suggestions = [Suggestion('Tom', 'Pixel'), Suggestion('Amina', 'Nala'), Suggestion('Jules', 'Oscar')];
    meetupGoing = false;
    onboardedAt = null;
  }

  void reset() {
    _seed();
    notifyListeners();
  }

  void update([VoidCallback? f]) {
    f?.call();
    notifyListeners();
  }

  /* ---------- derived ---------- */

  int get streak {
    var n = 0;
    for (var i = 6; i >= 0; i--) {
      if (week[i]) {
        n++;
      } else if (i == 6) {
        continue; // today not trained yet does not break the streak
      } else {
        break;
      }
    }
    return n;
  }

  String get camLabel =>
      camSource == CameraSource.petcam && petcamConnected ? 'Living room PetCam' : 'Phone camera';

  bool get usingPetcam => camSource == CameraSource.petcam && petcamConnected;

  List<(String, int, bool)> get board {
    final b = [for (final r in leaderboard) (r.$1, r.$2, false), ('You', weekXp, true)];
    b.sort((a, b) => b.$2.compareTo(a.$2));
    return b;
  }

  int get myRank => board.indexWhere((r) => r.$3) + 1;

  int get avgSessionDrop => checkins.isEmpty
      ? 0
      : (checkins.map((x) => (x.pre - x.post) / x.pre).reduce((a, b) => a + b) / checkins.length * 100).round();

  int get stressDropSinceStart => ((baseline['stress'] - latest['stress']) / baseline['stress'] * 100).round();

  String get nextLeague => tierNameAt(league + 1);
  String tierNameAt(int i) => const ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond'][min(i, 4)];

  /* ---------- actions ---------- */

  void finishOnboarding() {
    onboarded = true;
    onboardedAt = DateTime.now();
    if (latest['stress'] > baseline['stress']) latest['stress'] = baseline['stress'];
    notifyListeners();
  }

  void openTrick(String id) {
    recent = [id, ...recent.where((x) => x != id)];
    notifyListeners();
  }

  void markPractised(String id) {
    final m = tricks[id]!.mins;
    week[6] = true;
    minutes += m;
    todayMins += m;
    weekHist[weekHist.length - 1] += m;
    notifyListeners();
  }

  void startNextLesson() {
    const next = ['Fetch', 'Spin', 'Jump Through Hoop'];
    lesson = Lesson(lesson.n + 1, next[(lesson.n - 3) % 3]);
    notifyListeners();
  }

  void completeQuiz() {
    lesson.quiz = true;
    weekXp += 10;
    notifyListeners();
  }

  SessionSummary completeTraining(List<RepResult> reps, Duration elapsed) {
    final mins = max(1, (elapsed.inSeconds / 60).round());
    final acc = reps.isEmpty ? 0 : (reps.map((r) => r.score).reduce((a, b) => a + b) / reps.length).round();
    final best = reps.isEmpty ? 0.0 : reps.map((r) => r.hold).reduce(max);
    final clean = reps.where((r) => r.clean).length;
    final xp = 10 * reps.length + (acc / 5).round() + clean * 5;
    final before = myRank;
    lesson.training = true;
    week[6] = true;
    minutes += mins;
    todayMins += mins;
    weekHist[weekHist.length - 1] += mins;
    weekXp += xp;
    final thisW = weekHist.last, lastW = weekHist[weekHist.length - 2];
    final summary = SessionSummary(
      mins: mins,
      accuracy: acc,
      xp: xp,
      clean: clean,
      reps: reps.length,
      thisWeek: thisW,
      weekChangePct: ((thisW - lastW) / lastW * 100).round(),
      rankBefore: before,
      rankAfter: myRank,
      bestHold: best,
    );
    notifyListeners();
    return summary;
  }

  void recordCheckIn(int pre, int post, int? mood) {
    checkins.add(CheckIn('Today', pre, post, mood));
    if (checkins.length > 6) checkins.removeAt(0);
    latest['stress'] = post;
    notifyListeners();
  }

  void completeActivity() {
    lesson.activity = true;
    notifyListeners();
  }

  void addPost({required String caption, required String achievement, Uint8List? image}) {
    posts.insert(
        0,
        Post(
          id: DateTime.now().millisecondsSinceEpoch,
          who: 'You',
          cat: cat,
          time: 'now',
          achievement: achievement,
          caption: caption,
          likes: 0,
          hue: 260,
          image: image,
        ));
    notifyListeners();
  }

  void toggleLike(Post p) {
    p.liked = !p.liked;
    p.likes += p.liked ? 1 : -1;
    notifyListeners();
  }

  void addComment(Post p, String text) {
    p.comments.add(('You', text));
    notifyListeners();
  }

  void logWeight() {
    weight = [...weight.skip(1), double.parse((4.2 + Random().nextDouble() * 0.3).toStringAsFixed(1))];
    notifyListeners();
  }

  String? addCat() {
    final n = ['Pepper', 'Luna', 'Biscuit'].where((x) => !cats.contains(x)).firstOrNull;
    if (n != null) {
      cats.add(n);
      cat = n;
    }
    notifyListeners();
    return n;
  }
}

/* ============================== scope ============================== */

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child}) : super(notifier: state);

  /// Use in build methods: rebuilds when state changes.
  static AppState of(BuildContext c) => c.dependOnInheritedWidgetOfExactType<AppScope>()!.notifier!;

  /// Use in callbacks: no rebuild dependency.
  static AppState read(BuildContext c) => c.getInheritedWidgetOfExactType<AppScope>()!.notifier!;
}

extension StateX on BuildContext {
  AppState get s => AppScope.of(this);
  AppState get sr => AppScope.read(this);
}
