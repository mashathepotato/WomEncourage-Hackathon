import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../state.dart';
import '../theme.dart';

List<Widget> vspaced(List<Widget> items, double gap) {
  final out = <Widget>[];
  for (var i = 0; i < items.length; i++) {
    if (i > 0) out.add(SizedBox(height: gap));
    out.add(items[i]);
  }
  return out;
}

List<Widget> hspaced(List<Widget> items, double gap) {
  final out = <Widget>[];
  for (var i = 0; i < items.length; i++) {
    if (i > 0) out.add(SizedBox(width: gap));
    out.add(items[i]);
  }
  return out;
}

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.maybeOf(context)
    ?..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg),
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 2),
    ));
}

/// Clicker sound + haptic. `force` ignores the "Clicker sound" setting (header whistle).
void playClick(AppState s, {bool force = false}) {
  if (!force && s.settings['sounds'] != true) return;
  SystemSound.play(SystemSoundType.click);
  HapticFeedback.lightImpact();
}

Future<T?> showSheet<T>(BuildContext context, WidgetBuilder builder, {bool enableDrag = true}) {
  final c = context.c;
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    enableDrag: enableDrag,
    backgroundColor: c.screen,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: builder,
  );
}

class SheetBody extends StatelessWidget {
  final List<Widget> children;
  const SheetBody({super.key, required this.children});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(18, 20, 18, 26),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: vspaced(children, 14),
        ),
      ),
    );
  }
}

class SheetTitle extends StatelessWidget {
  final String text;
  final bool center;
  const SheetTitle(this.text, {super.key, this.center = false});
  @override
  Widget build(BuildContext context) => Text(text,
      textAlign: center ? TextAlign.center : TextAlign.start,
      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: context.c.accent));
}

class H2 extends StatelessWidget {
  final String text;
  final double size;
  const H2(this.text, {super.key, this.size = 17});
  @override
  Widget build(BuildContext context) =>
      Text(text, style: TextStyle(fontSize: size, fontWeight: FontWeight.w600, color: context.c.accent));
}

class Muted extends StatelessWidget {
  final String text;
  final double size;
  final TextAlign? align;
  const Muted(this.text, {super.key, this.size = 13, this.align});
  @override
  Widget build(BuildContext context) =>
      Text(text, textAlign: align, style: TextStyle(fontSize: size, color: context.c.muted, height: 1.45));
}

class Pill extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool ghost, small;
  final IconData? icon;
  final Color? background, foreground;
  const Pill(this.label,
      {super.key, this.onPressed, this.ghost = false, this.small = false, this.icon, this.background, this.foreground});

  @override
  Widget build(BuildContext context) {
    final c = context.c;
    final bg = background ?? (ghost ? c.soft : c.accent);
    final fg = foreground ?? (ghost ? c.accent : c.accentInk);
    return Opacity(
      opacity: onPressed == null ? 0.45 : 1,
      child: Material(
        color: bg,
        shape: const StadiumBorder(),
        child: InkWell(
          customBorder: const StadiumBorder(),
          onTap: onPressed,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: small ? 14 : 20, vertical: small ? 7 : 11),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[Icon(icon, size: 18, color: fg), const SizedBox(width: 6)],
                Flexible(
                  child: Text(label,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: fg, fontWeight: FontWeight.w500, fontSize: small ? 13 : 14)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ButtonRow extends StatelessWidget {
  final List<Widget> children;
  final WrapAlignment alignment;
  const ButtonRow(this.children, {super.key, this.alignment = WrapAlignment.end});
  @override
  Widget build(BuildContext context) => Wrap(
      alignment: alignment, spacing: 10, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: children);
}

class CardBox extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? color;
  const CardBox({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.color});
  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(color: color ?? context.c.card, borderRadius: BorderRadius.circular(16)),
        child: child,
      );
}

class Avatar extends StatelessWidget {
  final double size;
  const Avatar({super.key, this.size = 36});
  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: c.card, border: Border.all(color: c.accent, width: 2.5)),
      child: Icon(Icons.pets, size: size * 0.5, color: c.ink),
    );
  }
}

class Badge58 extends StatelessWidget {
  final IconData icon;
  final double size;
  const Badge58(this.icon, {super.key, this.size = 58});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, color: context.c.accent),
        child: Icon(icon, color: context.c.accentInk, size: size * 0.5),
      );
}

class Hero92 extends StatelessWidget {
  final IconData icon;
  final double size;
  const Hero92(this.icon, {super.key, this.size = 92});
  @override
  Widget build(BuildContext context) => Center(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(shape: BoxShape.circle, color: context.c.soft),
          child: Icon(icon, color: context.c.accent, size: size * 0.52),
        ),
      );
}

class TierShield extends StatelessWidget {
  final double size;
  final Color color;
  const TierShield({super.key, required this.size, required this.color});
  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: Stack(alignment: Alignment.center, children: [
          Icon(Icons.shield, size: size, color: color),
          Icon(Icons.star, size: size * 0.42, color: Colors.white.withOpacity(0.9)),
        ]),
      );
}

class StatTriple extends StatelessWidget {
  final List<(String, String)> items; // (value, label)
  const StatTriple(this.items, {super.key});
  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Row(
      children: [
        for (final it in items)
          Expanded(
            child: Column(children: [
              Text(it.$1,
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                      color: c.accent,
                      fontFeatures: const [FontFeature.tabularFigures()])),
              const SizedBox(height: 4),
              Text(it.$2.toUpperCase(),
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 10, letterSpacing: 0.6, fontWeight: FontWeight.w600, color: c.muted)),
            ]),
          ),
      ],
    );
  }
}

class HoldBar extends StatelessWidget {
  final double value; // 0..1
  final double? marker; // 0..1
  final Color? color;
  final double height;
  final double opacity;
  const HoldBar({super.key, required this.value, this.marker, this.color, this.height = 12, this.opacity = 1});
  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return SizedBox(
      height: height,
      child: LayoutBuilder(builder: (context, box) {
        return Stack(clipBehavior: Clip.none, children: [
          Container(decoration: BoxDecoration(color: c.soft, borderRadius: BorderRadius.circular(height / 2))),
          Container(
            width: box.maxWidth * value.clamp(0.0, 1.0),
            decoration: BoxDecoration(
                color: (color ?? c.accent).withOpacity(opacity), borderRadius: BorderRadius.circular(height / 2)),
          ),
          if (marker != null)
            Positioned(left: box.maxWidth * marker! - 1, top: -2, bottom: -2, child: Container(width: 2, color: c.ink)),
        ]);
      }),
    );
  }
}

/// good: true = green, false = orange (fix), null = neutral
class FeedbackTile extends StatelessWidget {
  final bool? good;
  final String title, body;
  const FeedbackTile({super.key, this.good, required this.title, required this.body});
  @override
  Widget build(BuildContext context) {
    final c = context.c;
    final edge = good == null ? c.line : (good! ? c.ok : c.warn);
    return Container(
      decoration: BoxDecoration(
        color: c.card,
        borderRadius: BorderRadius.circular(12),
        border: Border(left: BorderSide(color: edge, width: 4)),
      ),
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        const SizedBox(height: 2),
        Text(body, style: const TextStyle(fontSize: 13, height: 1.45)),
      ]),
    );
  }
}

class LabeledSlider extends StatelessWidget {
  final String label;
  final int value;
  final ValueChanged<int> onChanged;
  const LabeledSlider({super.key, required this.label, required this.value, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(children: [
        Expanded(child: Text(label, style: const TextStyle(fontSize: 14))),
        Text('$value%',
            style: TextStyle(
                fontWeight: FontWeight.w600, color: c.accent, fontFeatures: const [FontFeature.tabularFigures()])),
      ]),
      Slider(value: value.toDouble(), min: 0, max: 100, divisions: 100, onChanged: (v) => onChanged(v.round())),
    ]);
  }
}

class ToggleChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const ToggleChip({super.key, required this.label, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Material(
      color: selected ? c.soft : c.card,
      shape: StadiumBorder(side: BorderSide(color: selected ? c.accent : c.line, width: 2)),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          child: Text(label,
              style: TextStyle(
                  fontSize: 14,
                  color: selected ? c.accent : c.ink,
                  fontWeight: selected ? FontWeight.w500 : FontWeight.w400)),
        ),
      ),
    );
  }
}

class Segmented extends StatelessWidget {
  final List<String> labels;
  final int index;
  final ValueChanged<int> onChanged;
  const Segmented({super.key, required this.labels, required this.index, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: c.soft, borderRadius: BorderRadius.circular(12)),
      child: Row(children: [
        for (var i = 0; i < labels.length; i++)
          Expanded(
            child: GestureDetector(
              onTap: () => onChanged(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: i == index ? c.card : Colors.transparent,
                  borderRadius: BorderRadius.circular(9),
                ),
                alignment: Alignment.center,
                child: Text(labels[i], style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: c.accent)),
              ),
            ),
          ),
      ]),
    );
  }
}

class UnderlineTabs extends StatelessWidget {
  final List<String> labels;
  final int index;
  final ValueChanged<int> onChanged;
  const UnderlineTabs({super.key, required this.labels, required this.index, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Row(
      children: hspaced([
        for (var i = 0; i < labels.length; i++)
          Expanded(
            child: InkWell(
              onTap: () => onChanged(i),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 6),
                decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: i == index ? c.accent : c.line, width: 3))),
                alignment: Alignment.center,
                child: Text(labels[i],
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: i == index ? c.accent : c.muted)),
              ),
            ),
          ),
      ], 12),
    );
  }
}

class InfoRow extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final bool last;
  const InfoRow({super.key, required this.title, this.subtitle, this.trailing, this.last = false});
  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(border: last ? null : Border(bottom: BorderSide(color: c.line))),
      child: Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 14)),
            if (subtitle != null) Text(subtitle!, style: TextStyle(fontSize: 12, color: c.muted)),
          ]),
        ),
        if (trailing != null) ...[const SizedBox(width: 12), trailing!],
      ]),
    );
  }
}

class SelectTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final bool selected;
  final VoidCallback onTap;
  const SelectTile(
      {super.key, required this.icon, required this.title, required this.subtitle, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final c = context.c;
    return Material(
      color: c.card,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: selected ? c.accent : Colors.transparent, width: 2)),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Badge58(icon, size: 44),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                Text(subtitle, style: TextStyle(fontSize: 12, color: c.muted)),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
