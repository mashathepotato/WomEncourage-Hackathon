import 'dart:math';

import 'package:flutter/material.dart';

import '../state.dart';
import '../theme.dart';

void drawText(Canvas canvas, String text, Offset at, TextStyle style, {TextAlign align = TextAlign.left}) {
  final tp = TextPainter(text: TextSpan(text: text, style: style), textDirection: TextDirection.ltr)..layout();
  var dx = at.dx;
  if (align == TextAlign.center) dx -= tp.width / 2;
  if (align == TextAlign.right) dx -= tp.width;
  tp.paint(canvas, Offset(dx, at.dy - tp.height / 2));
}

void drawDashed(Canvas canvas, Path path, Paint paint, {double dash = 8, double gap = 6}) {
  for (final m in path.computeMetrics()) {
    var d = 0.0;
    while (d < m.length) {
      canvas.drawPath(m.extractPath(d, min(d + dash, m.length)), paint);
      d += dash + gap;
    }
  }
}

Path catHead(double s) {
  // simple cat silhouette in a 32x32 box, scaled by s/32
  final k = s / 32;
  return Path()
    ..moveTo(5 * k, 4 * k)
    ..lineTo(11 * k, 10 * k)
    ..lineTo(21 * k, 10 * k)
    ..lineTo(27 * k, 4 * k)
    ..lineTo(27 * k, 18 * k)
    ..arcToPoint(Offset(5 * k, 18 * k), radius: Radius.elliptical(11 * k, 10 * k), clockwise: true)
    ..close();
}

/* ---------------- logo ---------------- */

class LogoPainter extends CustomPainter {
  final AppColors c;
  LogoPainter(this.c);
  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 54, size.height / 44);
    final stroke = Paint()
      ..color = c.ink
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawRRect(RRect.fromLTRBR(17, 1, 37, 9, const Radius.circular(2)), stroke);
    final box = RRect.fromLTRBR(2, 7, 52, 39, const Radius.circular(3));
    canvas.drawRRect(box, Paint()..color = c.accent);
    canvas.drawRRect(box, stroke);
    final face = Paint()
      ..color = c.accentInk
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..strokeCap = StrokeCap.round;
    final head = Path()
      ..moveTo(19, 14)
      ..lineTo(23, 19)
      ..lineTo(31, 19)
      ..lineTo(35, 14)
      ..lineTo(35, 25)
      ..arcToPoint(const Offset(19, 25), radius: const Radius.elliptical(8, 7), clockwise: true)
      ..close();
    canvas.drawPath(head, face);
    for (final y in [25.0, 28.0]) {
      canvas.drawLine(Offset(10, y), Offset(19, y), face);
      canvas.drawLine(Offset(35, y), Offset(44, y), face);
    }
  }

  @override
  bool shouldRepaint(LogoPainter old) => old.c != c;
}

/* ---------------- placeholder post photo ---------------- */

class CatPhotoPainter extends CustomPainter {
  final double hue;
  CatPhotoPainter(this.hue);
  Color _h(double h, double s, double l) => HSLColor.fromAHSL(1, h % 360, s, l).toColor();
  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 400, size.height / 300);
    canvas.drawRect(const Rect.fromLTWH(0, 0, 400, 300), Paint()..color = _h(hue, .45, .82));
    canvas.drawRect(const Rect.fromLTWH(0, 210, 400, 90), Paint()..color = _h(hue, .30, .70));
    canvas.drawCircle(const Offset(330, 60), 30, Paint()..color = _h(hue, .60, .92));
    canvas.save();
    canvas.translate(200, 175);
    final fur = Paint()..color = _h(hue + 20, .25, .35);
    canvas.drawOval(Rect.fromCenter(center: const Offset(0, 40), width: 140, height: 120), fur);
    final head = Path()
      ..moveTo(-50, -60)
      ..lineTo(-32, -30)
      ..lineTo(32, -30)
      ..lineTo(50, -60)
      ..lineTo(54, 0)
      ..arcToPoint(const Offset(-54, 0), radius: const Radius.elliptical(54, 48), clockwise: true)
      ..close();
    canvas.drawPath(head, fur);
    final eye = Paint()..color = const Color(0xFFF2E7A8);
    canvas.drawCircle(const Offset(-20, -8), 6, eye);
    canvas.drawCircle(const Offset(20, -8), 6, eye);
    canvas.drawPath(
        Path()
          ..moveTo(-5, 8)
          ..lineTo(5, 8)
          ..lineTo(0, 14)
          ..close(),
        Paint()..color = const Color(0xFFE9A0A8));
    canvas.restore();
  }

  @override
  bool shouldRepaint(CatPhotoPainter old) => old.hue != hue;
}

/* ---------------- charts ---------------- */

class WeekBarsPainter extends CustomPainter {
  final List<int> values;
  final AppColors c;
  WeekBarsPainter(this.values, this.c);
  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 300, size.height / 120);
    final mx = max(values.reduce(max), 10).toDouble();
    double y(num v) => 100 - v / mx * 85;
    final label = TextStyle(fontSize: 9, color: c.muted);
    for (final v in [0, 20, 40]) {
      if (v > mx) continue;
      canvas.drawLine(Offset(24, y(v)), Offset(300, y(v)), Paint()..color = c.line);
      drawText(canvas, '$v', Offset(18, y(v)), label, align: TextAlign.right);
    }
    const names = ['1 Sep', '8 Sep', '15 Sep', '22 Sep'];
    for (var i = 0; i < values.length; i++) {
      final last = i == values.length - 1;
      final x = 36.0 + i * 54;
      canvas.drawRRect(RRect.fromLTRBR(x, y(values[i]), x + 34, 100, const Radius.circular(4)),
          Paint()..color = c.accent.withOpacity(last ? 1 : .45));
      drawText(canvas, last ? 'This wk' : names[i % names.length], Offset(x + 17, 113), label, align: TextAlign.center);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class WeightPainter extends CustomPainter {
  final List<double> w;
  final AppColors c;
  WeightPainter(this.w, this.c);
  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 320, size.height / 130);
    const lo = 4.0, hi = 4.6;
    double y(double v) => 110 - (v - lo) / (hi - lo) * 90;
    final label = TextStyle(fontSize: 10, color: c.muted);
    for (final v in [4.0, 4.2, 4.4, 4.6]) {
      canvas.drawLine(Offset(0, y(v)), Offset(320, y(v)), Paint()..color = c.line);
      drawText(canvas, v.toStringAsFixed(1), Offset(316, y(v) - 7), label, align: TextAlign.right);
    }
    final path = Path();
    for (var i = 0; i < w.length; i++) {
      final p = Offset(20.0 + i * 70, y(w[i]));
      i == 0 ? path.moveTo(p.dx, p.dy) : path.lineTo(p.dx, p.dy);
    }
    canvas.drawPath(
        path,
        Paint()
          ..color = c.accent
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..strokeJoin = StrokeJoin.round);
    const months = ['May', 'Jun', 'Jul', 'Aug', 'Sep'];
    for (var i = 0; i < w.length; i++) {
      final p = Offset(20.0 + i * 70, y(w[i]));
      canvas.drawCircle(p, i == w.length - 1 ? 6 : 4, Paint()..color = c.accent);
      drawText(canvas, months[i], Offset(p.dx, 124), label, align: TextAlign.center);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

/// Before (hollow) and after (filled) stress for each check-in.
class StressPainter extends CustomPainter {
  final List<CheckIn> data;
  final AppColors c;
  StressPainter(this.data, this.c);
  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 300, size.height / 120);
    double y(int v) => 100 - (v - 30) / 50 * 85;
    final label = TextStyle(fontSize: 9, color: c.muted);
    for (final v in [40, 60, 80]) {
      canvas.drawLine(Offset(24, y(v)), Offset(300, y(v)), Paint()..color = c.line);
      drawText(canvas, '$v', Offset(18, y(v)), label, align: TextAlign.right);
    }
    for (var i = 0; i < data.length; i++) {
      final x = 42.0 + i * 48;
      final d = data[i];
      canvas.drawLine(
          Offset(x, y(d.pre)),
          Offset(x, y(d.post)),
          Paint()
            ..color = c.accent.withOpacity(.5)
            ..strokeWidth = 2);
      canvas.drawCircle(Offset(x, y(d.pre)), 4, Paint()..color = c.card);
      canvas.drawCircle(
          Offset(x, y(d.pre)),
          4,
          Paint()
            ..color = c.accent
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2);
      canvas.drawCircle(Offset(x, y(d.post)), 4.5, Paint()..color = c.accent);
      drawText(canvas, d.day, Offset(x, 113), label, align: TextAlign.center);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

/* ---------------- neighbourhood map (340x250 space) ---------------- */

class MapPainter extends CustomPainter {
  final AppColors c;
  final int? selected;
  MapPainter(this.c, this.selected);
  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 340, size.height / 250);
    canvas.drawRect(const Rect.fromLTWH(0, 0, 340, 250), Paint()..color = c.card);
    canvas.drawRRect(RRect.fromLTRBR(120, 110, 200, 170, const Radius.circular(8)), Paint()..color = c.soft);
    drawText(canvas, 'Jardin des Tilleuls', const Offset(160, 140), TextStyle(fontSize: 9, color: c.muted),
        align: TextAlign.center);
    Paint road(double w) => Paint()
      ..color = c.line
      ..style = PaintingStyle.stroke
      ..strokeWidth = w;
    canvas.drawPath(Path()..moveTo(0, 40)..quadraticBezierTo(170, 20, 340, 50), road(10));
    canvas.drawLine(const Offset(0, 215), const Offset(340, 200), road(10));
    canvas.drawLine(const Offset(40, 0), const Offset(90, 250), road(8));
    canvas.drawLine(const Offset(270, 0), const Offset(250, 250), road(8));
    canvas.drawLine(const Offset(0, 110), const Offset(340, 105), road(6));
    // you
    canvas.drawCircle(const Offset(170, 100), 40, Paint()..color = c.accent.withOpacity(.12));
    canvas.drawCircle(const Offset(170, 100), 11, Paint()..color = c.card);
    canvas.drawCircle(const Offset(170, 100), 8, Paint()..color = c.accent);
    drawText(canvas, 'You', const Offset(170, 82), TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: c.accent),
        align: TextAlign.center);
    for (var i = 0; i < neighbours.length; i++) {
      final p = neighbours[i];
      canvas.drawCircle(p.pos, 22, Paint()..color = c.accent.withOpacity(selected == i ? .3 : .15));
      canvas.drawCircle(p.pos, 12, Paint()..color = p.friend ? c.ok : c.accent);
      canvas.save();
      canvas.translate(p.pos.dx - 7, p.pos.dy - 7);
      canvas.drawPath(catHead(14), Paint()..color = c.card);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(MapPainter old) => old.selected != selected || old.c != c;
}

/* ---------------- camera view with pose overlay (640x420 space) ---------------- */

class CameraPainter extends CustomPainter {
  final double raise; // 0..1 paw lift, already scaled by rep height
  final double holding; // seconds
  final double target; // seconds
  final double t; // seconds since start, for idle animation
  final String catName;
  CameraPainter({required this.raise, required this.holding, required this.target, required this.t, required this.catName});

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 640, size.height / 420);
    const bounds = Rect.fromLTWH(0, 0, 640, 420);
    canvas.drawRect(
        bounds,
        Paint()
          ..shader = const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF3A3747), Color(0xFF2C2A36), Color(0xFF4A3F37), Color(0xFF3A312B)],
            stops: [0, .7, .7, 1],
          ).createShader(bounds));
    canvas.drawOval(Rect.fromCenter(center: const Offset(300, 370), width: 400, height: 68), Paint()..color = const Color(0xFF5C4E7A));

    const cx = 280.0;
    final breathe = sin(t * 1000 / 600) * 2;
    const furC = Color(0xFFC9A27A), darkC = Color(0xFF8A6A4C), bellyC = Color(0xFFE8D5BC);
    final fur = Paint()..color = furC;

    // tail
    canvas.drawPath(
        Path()
          ..moveTo(cx + 60, 350)
          ..quadraticBezierTo(cx + 140, 350 + sin(t * 2.5) * 10, cx + 120, 290),
        Paint()
          ..color = furC
          ..style = PaintingStyle.stroke
          ..strokeWidth = 16
          ..strokeCap = StrokeCap.round);
    // body
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, 285 + breathe), width: 164, height: 180), fur);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, 300 + breathe), width: 80, height: 124), Paint()..color = bellyC);
    // head
    final hy = 165 + breathe - raise * 6;
    canvas.drawPath(
        Path()
          ..moveTo(cx - 52, hy - 10)
          ..lineTo(cx - 44, hy - 70)
          ..lineTo(cx - 10, hy - 40)
          ..lineTo(cx + 10, hy - 40)
          ..lineTo(cx + 44, hy - 70)
          ..lineTo(cx + 52, hy - 10)
          ..close(),
        fur);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, hy), width: 116, height: 100), fur);
    final stripe = Paint()
      ..color = darkC
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    for (final s in const [
      [-20.0, -38.0, -14.0, -24.0],
      [0.0, -44.0, 0.0, -28.0],
      [20.0, -38.0, 14.0, -24.0]
    ]) {
      canvas.drawLine(Offset(cx + s[0], hy + s[1]), Offset(cx + s[2], hy + s[3]), stripe);
    }
    final blink = (t * 1000) % 4000 < 120;
    for (final dx in [-22.0, 22.0]) {
      canvas.drawOval(Rect.fromCenter(center: Offset(cx + dx, hy + 2), width: 20, height: blink ? 3 : 18),
          Paint()..color = const Color(0xFFF2E7A8));
      if (!blink) {
        canvas.drawOval(Rect.fromCenter(center: Offset(cx + dx + raise * 4, hy + 2), width: 6, height: 16),
            Paint()..color = const Color(0xFF222222));
      }
    }
    canvas.drawPath(
        Path()
          ..moveTo(cx - 6, hy + 18)
          ..lineTo(cx + 6, hy + 18)
          ..lineTo(cx, hy + 25)
          ..close(),
        Paint()..color = const Color(0xFFE9A0A8));
    // left paw
    canvas.drawOval(Rect.fromCenter(center: const Offset(cx - 38, 368), width: 44, height: 28), fur);
    // right paw, lifted towards the hand
    const rest = Offset(cx + 38, 368), top = Offset(cx + 120, 190), shoulder = Offset(cx + 40, 255);
    final p = Offset.lerp(rest, top, raise)!;
    canvas.drawPath(
        Path()
          ..moveTo(shoulder.dx, shoulder.dy)
          ..quadraticBezierTo(shoulder.dx + 30 * raise, shoulder.dy + 60 - 40 * raise, p.dx, p.dy),
        Paint()
          ..color = furC
          ..style = PaintingStyle.stroke
          ..strokeWidth = 30
          ..strokeCap = StrokeCap.round);
    canvas.save();
    canvas.translate(p.dx, p.dy);
    canvas.rotate(-raise * 0.8);
    canvas.drawOval(Rect.fromCenter(center: Offset.zero, width: 40, height: 30), Paint()..color = bellyC);
    canvas.restore();
    // trainer's hand
    const hx = cx + 150, hyy = 175.0;
    final skin = Paint()..color = const Color(0xFFE7B98E);
    canvas.drawRRect(RRect.fromLTRBR(hx - 6, hyy - 38, hx + 44, hyy + 38, const Radius.circular(20)), skin);
    canvas.drawRect(Rect.fromLTWH(hx + 30, hyy + 30, 40, 90), skin);

    // ---- tracking overlay ----
    const acc = Color(0xFFA99BF0), ok = Color(0xFF6CD69C), amber = Color(0xFFFFD166);
    final boxW = raise > .1 ? 260.0 : 230.0;
    drawDashed(
        canvas,
        Path()..addRect(Rect.fromLTWH(cx - 110, hy - 80, boxW, 390 - (hy - 80))),
        Paint()
          ..color = acc
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2);
    canvas.drawRect(Rect.fromLTWH(cx - 110, hy - 104, 160, 24), Paint()..color = acc);
    drawText(canvas, '${catName.toLowerCase()} · cat 0.97', Offset(cx - 102, hy - 92),
        const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Color(0xFF17152A)));
    final kp = [Offset(cx - 44, hy - 62), Offset(cx + 44, hy - 62), Offset(cx, hy + 20), shoulder, p, const Offset(cx - 38, 368)];
    final bone = Paint()
      ..color = acc
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;
    canvas.drawPath(
        Path()
          ..moveTo(kp[0].dx, kp[0].dy)
          ..lineTo(kp[2].dx, kp[2].dy)
          ..lineTo(kp[1].dx, kp[1].dy)
          ..moveTo(kp[2].dx, kp[2].dy)
          ..lineTo(kp[3].dx, kp[3].dy)
          ..lineTo(kp[4].dx, kp[4].dy)
          ..moveTo(kp[2].dx, kp[2].dy)
          ..lineTo(kp[5].dx, kp[5].dy),
        bone);
    for (var i = 0; i < kp.length; i++) {
      final col = i == 4 ? (holding >= target ? ok : amber) : acc;
      canvas.drawCircle(kp[i], i == 4 ? 8 : 6, Paint()..color = col);
    }
    if (holding > 0) {
      final f = min(1.0, holding / target);
      canvas.drawArc(
          Rect.fromCircle(center: p, radius: 28),
          -pi / 2,
          f * 2 * pi,
          false,
          Paint()
            ..color = f >= 1 ? ok : amber
            ..style = PaintingStyle.stroke
            ..strokeWidth = 6);
      drawText(canvas, '${holding.toStringAsFixed(1)}s', Offset(p.dx - 60, p.dy - 34),
          const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white));
    }
    drawDashed(
        canvas,
        Path()..addOval(Rect.fromCircle(center: top, radius: 34)),
        Paint()
          ..color = Colors.white.withOpacity(.35)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5,
        dash: 4,
        gap: 5);
    drawText(canvas, 'target', Offset(top.dx, top.dy + 48), TextStyle(fontSize: 13, color: Colors.white.withOpacity(.6)),
        align: TextAlign.center);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
