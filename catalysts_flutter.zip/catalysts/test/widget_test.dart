import 'package:catalysts/services/pose_coach.dart';
import 'package:catalysts/state.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('pose coach produces scored reps', () {
    final coach = PoseCoach();
    var t = Duration.zero;
    while (coach.reps.length < 3) {
      t += const Duration(milliseconds: 16);
      coach.tick(t);
    }
    expect(coach.reps.length, 3);
    expect(coach.accuracy, inInclusiveRange(0, 100));
  });

  test('training updates streak, minutes and XP', () {
    final s = AppState();
    final xpBefore = s.weekXp;
    s.completeTraining(const [RepResult(2.2, 0.9, 94), RepResult(1.1, 0.6, 56)], const Duration(minutes: 3));
    expect(s.week[6], isTrue);
    expect(s.lesson.training, isTrue);
    expect(s.weekXp, greaterThan(xpBefore));
  });
}
