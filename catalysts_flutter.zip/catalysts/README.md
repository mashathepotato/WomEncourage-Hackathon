# CATalysts (Flutter)

Flutter port of the CATalysts prototype: camera-coached cat training, wellbeing check-ins, friends feed, nearby owners, leagues and Duolingo-style reminders.

## Run it

```bash
cd catalysts
flutter create . --project-name catalysts --platforms=android,ios   # generates android/ and ios/ folders
flutter pub get
flutter run
```

`flutter create .` keeps the existing `lib/`, `test/` and `pubspec.yaml`. Requires Flutter 3.22 or newer.

## Platform setup (one-time, after `flutter create`)

**Android** – `android/app/build.gradle` (needed by flutter_local_notifications):

```gradle
android {
    compileSdk 34
    compileOptions {
        coreLibraryDesugaringEnabled true
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
}
dependencies {
    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4'
}
```

If your project uses `build.gradle.kts`, the equivalents are `isCoreLibraryDesugaringEnabled = true` and `coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")`.

`android/app/src/main/AndroidManifest.xml`, inside `<manifest>`:

```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.CAMERA"/>
```

**iOS** – `ios/Runner/Info.plist`:

```xml
<key>NSPhotoLibraryUsageDescription</key>
<string>Share photos of your cat with friends.</string>
<key>NSCameraUsageDescription</key>
<string>The camera watches your cat during training to score each rep.</string>
```

## What's real and what's simulated

| Feature | Status |
|---|---|
| Onboarding survey, goals, camera choice | Real UI, stored in memory |
| Camera coaching (pose overlay, hold timer, per-rep feedback) | **Simulated** by `PoseCoach` in `lib/services/pose_coach.dart` |
| Pet camera pairing | **Simulated** discovery in `showPairSheet` |
| Summary stats, XP, league rank | Real logic on example data |
| Before/after stress check-ins, wellbeing charts | Real logic on example data |
| "Learn more" research links | Real, open in the browser |
| Friends feed: likes, comments, photo sharing | Real UI; photo picker is real (`image_picker`), posts stay on the device |
| Nearby map | Drawn map with example neighbours |
| Reminders | **Real OS notifications** (`flutter_local_notifications`): daily repeat and a test button in Settings. Tapping one opens the lesson. The "over another app" screen is an in-app preview |

State is in memory (`AppState` in `lib/state.dart`), so it resets when the app restarts.

## Production next steps

1. **Real motion detection.** Add the `camera` package, stream frames to a cat keypoint model (TFLite via `tflite_flutter`, e.g. a model trained on an animal pose dataset such as AP-10K). Feed the front-paw height and hold duration into `PoseCoach.tick`. Scoring, feedback, XP and summaries already consume that output.
2. **Pet camera.** Replace `showPairSheet` with the vendor SDK, or RTSP/ONVIF discovery plus a video player.
3. **Backend.** Accounts, friends, posts, likes, comments, leagues and the nearby map need a backend (e.g. Firebase Auth + Firestore + Storage). Store location only as a coarse area.
4. **Persistence.** Save `AppState` with `shared_preferences` or a local database.
5. **Reminder time.** Swap `periodicallyShow` for `zonedSchedule` (`timezone` package) to fire at a fixed time such as 18:30.
6. **Map.** Swap `MapPainter` for `flutter_map` (OpenStreetMap) or `google_maps_flutter`.
7. **Fonts offline.** `google_fonts` downloads Poppins on first run. To bundle it, add the font files as assets.

## Structure

```
lib/
  main.dart               app, bottom navigation, header, auto-reminder timer
  state.dart              models, example data, AppState, AppScope
  theme.dart              colour tokens (light + dark), Poppins
  widgets/common.dart     pills, cards, sliders, chips, sheets, toast
  widgets/painters.dart   logo, charts, map, camera view with pose overlay
  services/pose_coach.dart  rep simulation + coaching feedback rules
  services/reminders.dart   OS notifications
  screens/                home, library, community (feed/nearby/league), profile (progress/health/wellbeing), settings
  flows/                  onboarding, lesson flow (quiz → pre-check → training → summary → check-in → result → activity),
                          reminder preview, shared sheets (share, research, pairing, survey…)
test/widget_test.dart     unit tests for the coach and session logic
```
